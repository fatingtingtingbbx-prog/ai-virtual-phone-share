(() => {
  "use strict";
  const A = window.AiPhone || window.AiPhoneApp;
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];

  const state = {
    chars: [],
    characterId: "",
    mode: "auto",
    messages: [],
    events: [],
    routes: [],
    selectedEventKey: "",
    selectedRouteId: "",
    selectedMessageIds: new Set(),
    anchorTime: null,
    autoTiming: null,
    lastPreview: null,
    triggerDirty: false,
    editingRouteId: ""
  };

  const pad = n => String(n).padStart(2, "0");
  const localDateKey = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
  const hm = d => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const fmt = d => `${localDateKey(d)} ${hm(d)}`;
  const addMin = (d,n) => new Date(d.getTime()+n*60000);
  const safeText = v => String(v ?? "").trim();
  const norm = s => safeText(s).replace(/\s+/g, "");
  const clamp = (v,a,b) => Math.max(a, Math.min(b, v));
  const randInt = (a,b) => {
    const lo = Math.ceil(Math.min(a,b));
    const hi = Math.floor(Math.max(a,b));
    return lo + Math.floor(Math.random() * (hi-lo+1));
  };
  const asDate = (dateKey,time) => {
    const m = String(dateKey||"").match(/^(\d{4})-(\d{2})-(\d{2})$/);
    const t = String(time||"").match(/^(\d{1,2}):(\d{2})$/);
    return (!m||!t) ? null : new Date(+m[1], +m[2]-1, +m[3], +t[1], +t[2], 0, 0);
  };
  const parseLocalInput = v => v ? new Date(v) : null;
  const dateTimeLocalValue = d => `${localDateKey(d)}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const randomDate = (start,end) => new Date(randInt(start.getTime(), end.getTime()));
  const charName = id => state.chars.find(c=>c.id===id)?.name || id || "未命名角色";
  async function toast(message){ try{ await A.ui.toast(message); }catch{} }
  async function dbList(collection,limit=300){ try{return await A.db.list(collection,{limit});}catch{return [];} }

  function selectedMessages(){
    return state.messages
      .filter(m => state.selectedMessageIds.has(String(m.id)))
      .sort((a,b) => Date.parse(a.createdAt||0)-Date.parse(b.createdAt||0));
  }

  function updateSourceFromSelection(){
    const picked = selectedMessages();
    $("#sourceText").value = picked.map(m=>safeText(m.content)).filter(Boolean).join("\n");
    const validTimes = picked.map(m=>new Date(m.createdAt)).filter(d=>!Number.isNaN(d.getTime()));
    state.anchorTime = validTimes.length ? validTimes[validTimes.length-1] : null;
    const info = $("#anchorInfo");
    if(state.anchorTime){
      info.innerHTML = `<strong>真实起点：</strong>${fmt(state.anchorTime)}<br>相对“10分钟后 / 洗完 / 吃完”等时间，都从最后一条被选消息的时间开始算。`;
    }else{
      info.textContent = "还没有可用的消息时间锚点。";
    }
    state.triggerDirty = false;
    estimateAuto();
    refreshDefaultTriggerReason(true);
  }

  async function loadCharacters(){
    try{ state.chars = await A.characters.list(); }catch{ state.chars=[]; }
    const sel=$("#character"); sel.innerHTML="";
    for(const c of state.chars){
      const o=document.createElement("option"); o.value=c.id; o.textContent=c.name||c.id; sel.appendChild(o);
    }
    state.characterId = sel.value || state.chars[0]?.id || "";
  }

  async function loadMessages(){
    const host=$("#messages"); host.innerHTML='<div class="empty">读取中……</div>';
    state.selectedMessageIds.clear(); state.anchorTime=null; $("#sourceText").value="";
    if(!state.characterId){ host.innerHTML='<div class="empty">没有角色。</div>'; return; }
    try{
      const result=await A.chat.readHistory({characterId:state.characterId,limit:80});
      state.messages=(result?.messages||[])
        .filter(m=>m.role==="assistant" && safeText(m.content) && !m.isRetracted)
        .slice(-30).reverse();
      host.innerHTML="";
      if(!state.messages.length){ host.innerHTML='<div class="empty">还没有可选的角色消息。</div>'; return; }
      for(const m of state.messages){
        const label=document.createElement("label"); label.className="msg";
        const cb=document.createElement("input"); cb.type="checkbox"; cb.dataset.mid=String(m.id);
        const box=document.createElement("div"), text=document.createElement("div"), time=document.createElement("div");
        text.className="msgText"; text.textContent=safeText(m.content);
        time.className="msgTime"; time.textContent=m.createdAt?new Date(m.createdAt).toLocaleString():"";
        box.append(text,time); label.append(cb,box); host.appendChild(label);
        cb.onchange=()=>{
          if(cb.checked) state.selectedMessageIds.add(String(m.id)); else state.selectedMessageIds.delete(String(m.id));
          updateSourceFromSelection();
        };
      }
    }catch(e){ host.innerHTML=`<div class="empty">聊天历史读取失败：${e.message||e}</div>`; }
  }

  function eventKey(item,idx){return `${item.date||""}|${item.startTime||""}|${item.endTime||""}|${item.title||""}|${idx}`;}
  async function loadEvents(){
    const host=$("#events"); host.innerHTML='<div class="empty">读取中……</div>';
    if(!state.characterId){ host.innerHTML='<div class="empty">没有角色。</div>'; return; }
    try{
      const week=await A.calendar.read({ownerType:"character",ownerId:state.characterId,date:localDateKey(new Date())});
      const items=Array.isArray(week?.plan?.items)?week.plan.items:[];
      const now=new Date();
      state.events=items.map((item,idx)=>({item,key:eventKey(item,idx)}))
        .filter(x=>{
          const s=asDate(x.item.date,x.item.startTime),e=asDate(x.item.date,x.item.endTime);
          return (e&&e>=addMin(now,-720)) || (s&&s>=now);
        })
        .sort((a,b)=>(asDate(a.item.date,a.item.startTime)?.getTime()||0)-(asDate(b.item.date,b.item.startTime)?.getTime()||0))
        .slice(0,30);
      const ref=state.anchorTime||now;
      const current=state.events.find(x=>{const s=asDate(x.item.date,x.item.startTime),e=asDate(x.item.date,x.item.endTime);return s&&e&&s<=ref&&e>=ref;});
      state.selectedEventKey=(current||state.events[0])?.key||"";
      host.innerHTML="";
      if(!state.events.length){ host.innerHTML='<div class="empty">近期没有可用日程。</div>'; return; }
      for(const x of state.events){
        const row=document.createElement("label"); row.className="event";
        const radio=document.createElement("input"); radio.type="radio"; radio.name="event"; radio.value=x.key; radio.checked=x.key===state.selectedEventKey;
        const box=document.createElement("div"),title=document.createElement("div"),meta=document.createElement("div");
        title.className="eventTitle"; title.textContent=x.item.title||"未命名日程";
        meta.className="eventMeta"; meta.textContent=`${x.item.date||""} ${x.item.startTime||"??"}-${x.item.endTime||"??"}${x.item.location?` · ${x.item.location}`:""}`;
        box.append(title,meta); row.append(radio,box); host.appendChild(row);
        radio.onchange=()=>{ state.selectedEventKey=x.key; refreshDefaultTriggerReason(); };
      }
    }catch(e){ host.innerHTML=`<div class="empty">日历读取失败：${e.message||e}</div>`; }
  }

  async function loadRoutes(){
    state.routes=(await dbList("routes",300))
      .filter(r=>r.version==="0.5" && r.characterId===state.characterId)
      .sort((a,b)=>String(a.from).localeCompare(String(b.from),"zh-CN")||String(a.to).localeCompare(String(b.to),"zh-CN"));
    renderRoutes(); renderRouteSelect();
  }

  function renderRouteSelect(){
    const sel=$("#routeSelect"); sel.innerHTML="";
    if(!state.routes.length){ const o=document.createElement("option");o.value="";o.textContent="暂无常用路线";sel.appendChild(o);state.selectedRouteId="";return; }
    for(const r of state.routes){
      const o=document.createElement("option");o.value=r.id;o.textContent=`${r.from} → ${r.to} · ${r.min}-${r.max} 分钟`;sel.appendChild(o);
    }
    if(state.selectedRouteId && state.routes.some(r=>r.id===state.selectedRouteId)) sel.value=state.selectedRouteId;
    state.selectedRouteId=sel.value;
  }

  function renderRoutes(){
    const host=$("#routeList"); host.innerHTML="";
    if(!state.routes.length){ host.innerHTML='<div class="empty">这个角色还没有常用路线。先只存真正高频的几条就够了。</div>'; return; }
    for(const r of state.routes){
      const box=document.createElement("div");box.className="routeBox";
      const top=document.createElement("div");top.className="routeTop";
      const name=document.createElement("div");name.className="routeName";name.textContent=`${r.from} → ${r.to}`;
      const info=document.createElement("div");info.className="routeInfo";info.textContent=`通常 ${r.min}～${r.max} 分钟`;
      top.append(name);box.append(top,info);
      const acts=document.createElement("div");acts.className="routeActions";
      const edit=document.createElement("button");edit.className="tiny";edit.textContent="编辑";edit.onclick=()=>startEditRoute(r);
      const del=document.createElement("button");del.className="tiny danger";del.textContent="删除";del.onclick=()=>deleteRoute(r);
      acts.append(edit,del);box.append(acts);host.appendChild(box);
    }
  }

  function startEditRoute(r){
    state.editingRouteId=r.id; $("#routeFrom").value=r.from; $("#routeTo").value=r.to; $("#routeMin").value=r.min; $("#routeMax").value=r.max;
    $("#saveRoute").textContent="保存修改"; $("#cancelRouteEdit").hidden=false;
  }
  function cancelEditRoute(){
    state.editingRouteId=""; $("#routeFrom").value=""; $("#routeTo").value=""; $("#routeMin").value=25; $("#routeMax").value=40;
    $("#saveRoute").textContent="添加常用路线"; $("#cancelRouteEdit").hidden=true;
  }
  async function saveRoute(){
    try{
      const from=safeText($("#routeFrom").value),to=safeText($("#routeTo").value),min=+$("#routeMin").value,max=+$("#routeMax").value;
      if(!from||!to) throw new Error("起点和终点都要填。");
      if(!Number.isFinite(min)||!Number.isFinite(max)||min<1||max<min) throw new Error("路线时间范围不对。");
      if(state.editingRouteId){
        await A.db.update("routes",state.editingRouteId,{from,to,min,max,characterId:state.characterId,version:"0.5"}); await toast("路线已更新");
      }else{
        await A.db.create("routes",{characterId:state.characterId,from,to,min,max,version:"0.5"}); await toast("常用路线已添加");
      }
      cancelEditRoute(); await loadRoutes(); estimateAuto(); refreshDefaultTriggerReason();
    }catch(e){ await toast(`保存失败：${e.message||e}`); }
  }
  async function deleteRoute(r){
    try{ await A.db.delete("routes",r.id); if(state.selectedRouteId===r.id)state.selectedRouteId=""; await loadRoutes(); await toast("路线已删除"); estimateAuto(); }
    catch(e){ await toast(`删除失败：${e.message||e}`); }
  }

  const eventSemantic=[
    {name:"健身",event:/(健身|运动|训练|跑步|游泳|瑜伽)/,text:/(练完|健身完|运动完|训练完|跑完|游完|瑜伽完|结束训练|练完找)/},
    {name:"会议",event:/(会议|开会|例会|产品会|客户会)/,text:/(开完会|散会|会议结束|会结束|会后|开完再)/},
    {name:"上课",event:/(上课|课程|课堂|讲课)/,text:/(下课|上完课|课结束|讲完课)/},
    {name:"电影/演出",event:/(电影|演出|音乐会|话剧|展映)/,text:/(散场|看完电影|电影结束|演出结束|看完演出)/},
    {name:"工作",event:/(工作|公司|办公|加班)/,text:/(下班|收工|工作结束|忙完工作|忙完)/}
  ];

  const lifestyleRules=[
    {name:"换衣服",re:/(换衣|换完衣服|换好衣服|更衣)/,buckets:[{w:18,min:4,max:7},{w:62,min:7,max:12},{w:20,min:12,max:18}]},
    {name:"洗澡",re:/(洗澡|冲澡|淋浴|洗完澡|冲完澡)/,buckets:[{w:15,min:14,max:22},{w:65,min:22,max:35},{w:20,min:35,max:50}]},
    {name:"吃饭",re:/(吃饭|吃完饭|午饭|晚饭|早餐|用餐)/,buckets:[{w:15,min:20,max:30},{w:65,min:30,max:45},{w:20,min:45,max:65}]},
    {name:"做饭再吃",re:/(做饭|做菜|下厨)/,buckets:[{w:12,min:35,max:50},{w:62,min:50,max:75},{w:26,min:75,max:105}]},
    {name:"收拾整理",re:/(收拾|整理|弄完东西|打扫)/,buckets:[{w:20,min:8,max:15},{w:65,min:15,max:30},{w:15,min:30,max:45}]},
    {name:"买东西/短暂外出",re:/(买东西|便利店|超市|取快递|拿快递)/,buckets:[{w:18,min:15,max:25},{w:62,min:25,max:45},{w:20,min:45,max:70}]},
    {name:"短暂休息",re:/(休息一下|歇会|眯一会|小睡|午睡)/,buckets:[{w:25,min:20,max:35},{w:55,min:35,max:60},{w:20,min:60,max:95}]}
  ];

  function timeTendency(text){
    const s=norm(text);
    if(/(冲一下|简单洗|很快|快点|抓紧|赶时间|马上回来|一会儿就好|随便冲冲)/.test(s)) return "fast";
    if(/(多洗会|多洗一会|泡一会|泡会儿|慢慢来|不着急|久一点|多待会|多待一会)/.test(s)) return "slow";
    return "normal";
  }

  function weightedBucket(buckets,tendency="normal"){
    let arr=buckets.map(x=>({...x}));
    if(tendency==="fast") arr=arr.map((x,i)=>({...x,w:x.w*(i===0?3:i===1?0.85:0.25)}));
    if(tendency==="slow") arr=arr.map((x,i)=>({...x,w:x.w*(i===2?3:i===1?0.85:0.25)}));
    const total=arr.reduce((s,x)=>s+x.w,0); let r=Math.random()*total;
    for(const x of arr){ r-=x.w; if(r<=0)return x; }
    return arr[arr.length-1];
  }

  function makeRelativeWindow(anchor,min,max,label,why,meta={}){
    const now=new Date(), start=addMin(anchor,min), end=addMin(anchor,max);
    if(end<=now) throw new Error("按原消息时间计算，这个预计联系窗口已经过去了。请改用“我来改”。");
    const usableStart=start<addMin(now,1)?addMin(now,1):start;
    return {source:"relative",sourceLabel:label,windowStart:usableStart,windowEnd:end,runAt:randomDate(usableStart,end),why,...meta};
  }

  function explicitDuration(text,anchor){
    const s=norm(text); let m=s.match(/(\d{1,3})分钟(?:后|以后|之后|再)?/);
    if(m){ const n=+m[1]; if(n>0&&n<=720)return makeRelativeWindow(anchor,Math.max(1,n-2),n+6,`原话里的 ${n} 分钟`,`从被选消息的真实时间 ${hm(anchor)} 开始计算，再做很小的自然浮动。`,{kind:"explicit"}); }
    if(/半个?小时/.test(s)) return makeRelativeWindow(anchor,25,40,"原话里的半小时",`从被选消息的真实时间 ${hm(anchor)} 开始计算。`,{kind:"explicit"});
    m=s.match(/(\d{1,2})(?:个)?小时(?:后|以后|之后|再)?/);
    if(m){ const n=+m[1]*60; if(n>0&&n<=720)return makeRelativeWindow(anchor,Math.max(1,n-5),n+15,`原话里的 ${m[1]} 小时`,`从被选消息的真实时间 ${hm(anchor)} 开始计算。`,{kind:"explicit"}); }
    return null;
  }

  function explicitClock(text,anchor){
    const s=norm(text);
    const m=s.match(/(明天|今晚|晚上|下午|上午|早上)?(\d{1,2})(?:[:：点时](\d{1,2})?)?(?:点半)?/);
    if(!m) return null;
    if(!/(点|[:：]|明天|今晚|晚上|下午|上午|早上)/.test(m[0])) return null;
    let h=+m[2], minute=m[3]!==undefined&&m[3]!==""?+m[3]:0;
    if(/点半/.test(m[0])) minute=30;
    const part=m[1]||"";
    if((part==="下午"||part==="晚上"||part==="今晚")&&h<12)h+=12;
    if(part==="上午"||part==="早上"){ if(h===12)h=0; }
    if(h>23||minute>59)return null;
    const target=new Date(anchor); target.setHours(h,minute,0,0);
    if(part==="明天") target.setDate(target.getDate()+1);
    else if(target<=anchor && !part) return null;
    const now=new Date();
    const start=addMin(target,-3),end=addMin(target,8);
    if(end<=now)return null;
    const usable=start<addMin(now,1)?addMin(now,1):start;
    return {source:"clock",sourceLabel:`原话里的明确时间 ${hm(target)}`,windowStart:usable,windowEnd:end,runAt:randomDate(usable,end),why:"原话给出了明确钟点，只做很小的自然浮动。",kind:"explicit_clock"};
  }

  function naturalCalendarWindow(item,anchor="end",preset="natural"){
    const now=new Date(),base=asDate(item.date,anchor==="start"?item.startTime:item.endTime); if(!base)throw new Error("日程缺少可用时间。");
    let early,late; const title=norm(item.title);
    if(anchor==="start"){ const map={tight:[-8,-2],natural:[-15,-3],loose:[-25,-2]}; [early,late]=map[preset]||map.natural; }
    else if(/会议|开会|例会|客户/.test(title)){ const map={tight:[0,12],natural:[-3,30],loose:[-5,50]}; [early,late]=map[preset]||map.natural; }
    else if(/健身|运动|训练|跑步|游泳|瑜伽/.test(title)){ const map={tight:[-5,15],natural:[-10,30],loose:[-15,50]}; [early,late]=map[preset]||map.natural; }
    else if(/课程|上课|课堂|电影|演出|音乐会/.test(title)){ const map={tight:[-2,10],natural:[-5,18],loose:[-10,30]}; [early,late]=map[preset]||map.natural; }
    else { const map={tight:[-3,12],natural:[-7,25],loose:[-15,45]}; [early,late]=map[preset]||map.natural; }
    let start=addMin(base,early),end=addMin(base,late); const minFuture=addMin(now,1);
    if(end<=now)throw new Error("这个日历联系窗口已经过去了。"); if(start<minFuture)start=minFuture;
    return {source:"calendar",sourceLabel:`日历：${item.date} ${item.startTime}-${item.endTime} ${item.title||""} · ${anchor==="start"?"开始前":"结束附近"}`,windowStart:start,windowEnd:end,runAt:randomDate(start,end),calendarItem:item,calendarAnchor:anchor,why:`使用日历事件「${item.title||"未命名"}」的${anchor==="start"?"开始时间":"结束时间"}，再加自然浮动。`,kind:"calendar"};
  }

  function chooseCalendarSuggestion(text){
    const ref=state.anchorTime||new Date(),s=norm(text);
    const current=state.events.find(x=>{const a=asDate(x.item.date,x.item.startTime),b=asDate(x.item.date,x.item.endTime);return a&&b&&a<=ref&&b>=ref;});
    const next=state.events.find(x=>{const a=asDate(x.item.date,x.item.startTime);return a&&a>ref;});
    const before=/开始前|开场前|出发前|上场前|进去前/.test(s);
    if(before&&next)return {x:next,anchor:"start",reason:"原话带有“开始前”一类时间锚点，匹配最近的下一项日程。"};
    for(const x of [current,next].filter(Boolean)){
      for(const rule of eventSemantic){ if(rule.event.test(norm(x.item.title))&&rule.text.test(s))return {x,anchor:"end",reason:`原话与日程「${x.item.title}」语义匹配。`}; }
    }
    if(current&&/(结束后|结束了|结束再|忙完|完了找|完再|出来找|出来再)/.test(s))return {x:current,anchor:"end",reason:"原话指向当前活动结束后的联系，采用消息发出时正在进行的日程。"};
    return null;
  }

  function findRouteSuggestion(text){
    const s=norm(text); if(!state.routes.length)return null;
    const scored=state.routes.map(r=>{
      const from=norm(r.from),to=norm(r.to); let score=0;
      if(from&&s.includes(from))score+=3; if(to&&s.includes(to))score+=4;
      if(from&&to&&s.includes(from)&&s.includes(to))score+=5;
      if(to==="家"&&/回家|到家/.test(s))score+=3;
      if(to==="公司"&&/回公司|到公司/.test(s))score+=3;
      if(to==="健身房"&&/去健身房|到健身房/.test(s))score+=3;
      return {r,score};
    }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score);
    if(!scored.length)return null;
    if(scored[0].score>=8 || (scored.length===1 && scored[0].score>=5) || (scored[0].score>scored[1]?.score)) return scored[0].r;
    return null;
  }

  function routeTiming(route,status="normal",note=""){
    if(!state.anchorTime)throw new Error("没有来源消息时间，无法计算通勤起点。");
    let min=+route.min,max=+route.max;
    if(status==="fast"){ min=Math.max(1,Math.round(min*0.75)); max=Math.max(min,Math.round(max*0.90)); }
    if(status==="slow"){ min=Math.max(1,Math.round(min*1.15)); max=Math.max(min,Math.round(max*1.45)); }
    if(status==="custom"){ min=+$("#routeCustomMin").value; max=+$("#routeCustomMax").value; if(!Number.isFinite(min)||!Number.isFinite(max)||min<1||max<min)throw new Error("自定义通勤时间范围不对。"); }
    const label=`路线：${route.from} → ${route.to} · ${status==="normal"?"正常":status==="fast"?"偏快":status==="slow"?"偏慢":"自定义"}`;
    return makeRelativeWindow(state.anchorTime,min,max,label,`使用 ${charName(state.characterId)} 自己保存的常用路线。${note?`\n本次备注：${note}`:""}`,{source:"route",kind:"route",route,routeStatus:status,routeNote:note});
  }

  function lifestyleTiming(text,rule){
    if(!state.anchorTime)throw new Error("没有来源消息时间，无法计算生活事件起点。");
    const tendency=timeTendency(text),bucket=weightedBucket(rule.buckets,tendency);
    const tendencyLabel=tendency==="fast"?"（原话明确偏快）":tendency==="slow"?"（原话明确偏慢）":"";
    return makeRelativeWindow(state.anchorTime,bucket.min,bucket.max,`生活事件：${rule.name}${tendencyLabel}`,`采用带权重的自然耗时分布：大多数落在常见时长，偶尔更快或更久。插件不会替角色编“为什么这次花了这么久”。`,{kind:"lifestyle",activity:rule.name,tendency});
  }

  function estimateAuto(){
    state.lastPreview=null;
    const text=safeText($("#sourceText")?.value),box=$("#recommend"); if(!box)return;
    if(!text||!state.anchorTime){state.autoTiming=null;box.querySelector(".big").textContent="先选一句消息。";box.querySelector(".why").textContent="不会调用模型。";return;}
    try{
      let timing=explicitDuration(text,state.anchorTime) || explicitClock(text,state.anchorTime);
      if(timing){ state.autoTiming=timing; renderRecommendation(); refreshDefaultTriggerReason(); return; }
      const cal=chooseCalendarSuggestion(text);
      if(cal){ timing=naturalCalendarWindow(cal.x.item,cal.anchor,"natural"); timing.source="auto_calendar"; timing.sourceLabel=`自动匹配 ${timing.sourceLabel}`; timing.why=cal.reason+"\n"+timing.why; state.autoTiming=timing; renderRecommendation(); refreshDefaultTriggerReason(); return; }
      const route=findRouteSuggestion(text);
      if(route){ timing=routeTiming(route,"normal",""); timing.source="auto_route"; timing.sourceLabel=`自动匹配 ${timing.sourceLabel}`; timing.why="原话能唯一匹配到这个角色保存的常用路线。\n"+timing.why; state.autoTiming=timing; renderRecommendation(); refreshDefaultTriggerReason(); return; }
      const s=norm(text),rule=lifestyleRules.find(r=>r.re.test(s));
      if(rule){ timing=lifestyleTiming(text,rule); state.autoTiming=timing; renderRecommendation(); refreshDefaultTriggerReason(); return; }
      if(/回家|到家|通勤|路上|回公司|到公司|回宿舍|到宿舍|出发/.test(s)){
        timing=makeRelativeWindow(state.anchorTime,25,60,"未匹配到常用路线 · 临时通勤 25～60 分钟","没找到唯一的角色常用路线。非常用路线可以直接切到“我来改”；如果其实是高频路线，建议存进路线库。",{kind:"route_fallback"});
        state.autoTiming=timing; renderRecommendation(); refreshDefaultTriggerReason(); return;
      }
      timing=makeRelativeWindow(state.anchorTime,20,50,"普通短暂离开 · 自然兜底","没有匹配到明确时间、日历、常用路线或生活事件，使用保守的本地兜底窗口。",{kind:"generic"});
      state.autoTiming=timing; renderRecommendation(); refreshDefaultTriggerReason();
    }catch(e){ state.autoTiming=null; box.querySelector(".big").textContent="暂时没估出来。"; box.querySelector(".why").textContent=String(e.message||e); refreshDefaultTriggerReason(); }
  }

  function renderRecommendation(){
    const p=state.autoTiming,box=$("#recommend"); if(!p)return;
    box.querySelector(".big").textContent=`${fmt(p.windowStart)} ～ ${fmt(p.windowEnd)}`;
    box.querySelector(".why").textContent=`${p.sourceLabel}\n${p.why||""}`;
  }

  function manualCalendarTiming(){
    const x=state.events.find(e=>e.key===state.selectedEventKey); if(!x)throw new Error("先选一个日历事件。");
    return naturalCalendarWindow(x.item,$("#calendarAnchor").value,$("#calendarPreset").value);
  }
  function manualRouteTiming(){
    const route=state.routes.find(r=>r.id===$("#routeSelect").value); if(!route)throw new Error("先添加并选择一条常用路线。");
    return routeTiming(route,$("#routeStatus").value,safeText($("#routeNote").value));
  }
  function customTiming(){
    const start=parseLocalInput($("#customStart").value),end=parseLocalInput($("#customEnd").value),now=new Date();
    if(!start||!end)throw new Error("请填写完整的时间窗。"); if(end<=start)throw new Error("结束时间必须晚于开始时间。"); if(end<=now)throw new Error("这个时间窗已经过去了。");
    const usable=start<addMin(now,1)?addMin(now,1):start;
    return {source:"custom",sourceLabel:`自定义 ${fmt(usable)}～${fmt(end)}`,windowStart:usable,windowEnd:end,runAt:randomDate(usable,end),why:"你手动覆盖了插件的估时。",kind:"custom"};
  }
  function buildTiming(){
    if(state.mode==="custom")return customTiming();
    if(state.mode==="calendar")return manualCalendarTiming();
    if(state.mode==="route")return manualRouteTiming();
    if(!state.autoTiming) estimateAuto();
    if(!state.autoTiming)throw new Error("自动估时失败，请改用日历、路线或自定义。");
    return {...state.autoTiming};
  }

  function formSignature(){
    return JSON.stringify({
      characterId:state.characterId,
      messageIds:[...state.selectedMessageIds].sort(),
      sourceText:safeText($("#sourceText")?.value),
      anchorTime:state.anchorTime?.toISOString()||"",
      mode:state.mode,
      triggerReason:safeText($("#triggerReason")?.value),
      selectedEventKey:state.selectedEventKey,
      calendarAnchor:$("#calendarAnchor")?.value||"",
      calendarPreset:$("#calendarPreset")?.value||"",
      routeId:$("#routeSelect")?.value||"",
      routeStatus:$("#routeStatus")?.value||"",
      routeNote:safeText($("#routeNote")?.value),
      routeCustomMin:$("#routeCustomMin")?.value||"",
      routeCustomMax:$("#routeCustomMax")?.value||"",
      customStart:$("#customStart")?.value||"",
      customEnd:$("#customEnd")?.value||""
    });
  }

  function defaultTriggerReason(timing=null){
    const source=safeText($("#sourceText").value); if(!source)return "";
    const t=timing || (state.mode==="auto"?state.autoTiming:null);
    const quote=source.length>900?source.slice(0,900)+"…":source;
    let opening="你之前打算在合适的时候主动联系对方，现在已经到了这个时间附近。";
    if(t?.kind==="calendar"){
      const title=safeText(t.calendarItem?.title)||"刚才的日程";
      opening=t.calendarAnchor==="start"?`日历中的「${title}」即将开始，你之前打算在开始前主动联系对方。`:`你刚结束日历中的「${title}」，现在已经回到适合看手机和聊天的状态。`;
    }else if(t?.kind==="route" || t?.kind==="route_fallback"){
      if(t.route) opening=`你已经结束从「${t.route.from}」到「${t.route.to}」的这次通勤，现在到了之前打算主动联系对方的时候。`;
      else opening="你已经结束刚才的通勤/移动，现在到了之前打算主动联系对方的时候。";
      if(t.routeNote) opening+=` 这次通勤有一个背景情况：${t.routeNote}。`;
    }else if(t?.kind==="lifestyle"){
      opening=`你刚结束「${t.activity}」这件事，现在到了之前打算主动联系对方的时候。`;
    }else if(t?.kind==="explicit" || t?.kind==="explicit_clock"){
      opening="已经到了你之前自己说好的联系时间附近。";
    }
    return `${opening}\n此前聊天中的来源是：“${quote}”\n结合当前真实时间、最近聊天、日历、你的角色设定与此刻状态，自然地主动回来找对方。不要机械复述来源原话，不要表现成是对方刚刚叫你来的，不要问“怎么了 / 找我有事吗”，也不要提提醒、任务、插件或系统。直接从你此刻真正会发出的内容开始。`;
  }

  function refreshDefaultTriggerReason(force=false){
    const box=$("#triggerReason"); if(!box)return;
    if(force || !state.triggerDirty) box.value=defaultTriggerReason(state.mode==="auto"?state.autoTiming:null);
  }

  function buildPreview(){
    const source=safeText($("#sourceText").value); if(!source)throw new Error("先选择一条来源消息。"); if(!state.anchorTime)throw new Error("来源消息没有可用时间戳。"); if(!state.characterId)throw new Error("先选择角色。");
    const timing=buildTiming();
    if(!state.triggerDirty) $("#triggerReason").value=defaultTriggerReason(timing);
    const reason=safeText($("#triggerReason").value)||defaultTriggerReason(timing);
    const result={...timing,sourceText:source,sourceMessageIds:[...state.selectedMessageIds],anchorTime:new Date(state.anchorTime),triggerReason:reason,characterId:state.characterId,characterName:charName(state.characterId)};
    result.signature=formSignature();
    state.lastPreview=result; return result;
  }

  function previewForSchedule(){
    const sig=formSignature();
    const p=state.lastPreview;
    if(p && p.signature===sig && new Date(p.runAt).getTime()>Date.now()+1000) return p;
    return buildPreview();
  }

  function showPreview(){
    try{
      const p=buildPreview();
      $("#previewBox").textContent=`角色：${p.characterName}\n来源消息：${p.sourceText}\n真实起点：${fmt(p.anchorTime)}\n依据：${p.sourceLabel}\n联系窗口：${fmt(p.windowStart)} ～ ${fmt(p.windowEnd)}${$("#showExact").checked?`\n本次随机点：${fmt(p.runAt)}`:""}\n\n隐藏触发原因：\n${p.triggerReason}`;
    }catch(e){ $("#previewBox").textContent=`试算失败：${e.message||e}`; }
  }

  async function createPlanTask(p, extra={}){
    const taskId=`ruyue_v05_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
    const eventId=`ruyue_trigger_${taskId}`;
    const delayMs=Math.max(1000,new Date(p.runAt).getTime()-Date.now());
    const planRecord=await A.db.create("plans",{
      taskId,eventId,characterId:p.characterId,characterName:p.characterName,
      sourceText:p.sourceText,sourceMessageIds:p.sourceMessageIds||[],anchorTime:new Date(p.anchorTime).toISOString(),triggerReason:p.triggerReason,
      source:p.source,sourceLabel:p.sourceLabel,windowStart:new Date(p.windowStart).toISOString(),windowEnd:new Date(p.windowEnd).toISOString(),runAt:new Date(p.runAt).toISOString(),
      status:"pending",version:"0.5",...extra
    });
    try{
      await A.tasks.schedule({
        id:taskId,delayMs,
        actions:[
          {type:"memory.timeline",characterId:p.characterId,summary:p.triggerReason,detail:"如约来信 · 主动回来",appLabel:"如约来信",appEventId:eventId,data:{kind:"ruyue_trigger",taskId,planId:planRecord.id}},
          {type:"chat.reply",characterId:p.characterId}
        ],
        onSuccess:[
          {type:"db.update",collection:"plans",id:planRecord.id,patch:{status:"done"}}
        ],
        onFailure:[
          {type:"memory.deleteTimeline",characterId:p.characterId,appEventId:eventId},
          {type:"db.update",collection:"plans",id:planRecord.id,patch:{status:"failed"}}
        ]
      });
      return planRecord;
    }catch(e){
      try{await A.db.delete("plans",planRecord.id);}catch{}
      throw e;
    }
  }

  async function schedule(){
    try{
      const p=previewForSchedule();
      await createPlanTask(p);
      await toast("这次如约已登记");
      $("#previewBox").textContent=`已登记：${p.characterName}\n真实起点：${fmt(p.anchorTime)}\n联系窗口：${fmt(p.windowStart)} ～ ${fmt(p.windowEnd)}${$("#showExact").checked?`\n测试精确点：${fmt(p.runAt)}`:""}\n\n到点只触发一次普通聊天回复。`;
      state.lastPreview=null;
      await renderPlans();
    }catch(e){
      await toast(`登记失败：${e.message||e}`); $("#previewBox").textContent=`登记失败：${e.message||e}`;
    }
  }

  async function reschedulePlan(plan,startValue,endValue){
    try{
      const start=parseLocalInput(startValue),end=parseLocalInput(endValue),now=new Date();
      if(!start||!end)throw new Error("请填写完整的新时间窗。");
      if(end<=start)throw new Error("结束时间必须晚于开始时间。");
      if(end<=now)throw new Error("新的时间窗已经过去了。");
      const usable=start<addMin(now,1)?addMin(now,1):start;
      const canceled=await A.tasks.cancel(String(plan.taskId));
      if(!canceled)throw new Error("旧任务已经不在等待状态，先刷新计划列表确认一下。");
      await A.db.update("plans",plan.id,{status:"canceled",cancelReason:"已调整为新计划",canceledAt:new Date().toISOString()});
      const p={
        characterId:plan.characterId,characterName:plan.characterName||charName(plan.characterId),
        sourceText:plan.sourceText||"",sourceMessageIds:Array.isArray(plan.sourceMessageIds)?plan.sourceMessageIds:[],
        anchorTime:new Date(plan.anchorTime),triggerReason:plan.triggerReason||"",
        source:"adjusted",sourceLabel:"手动调整时间",
        windowStart:usable,windowEnd:end,runAt:randomDate(usable,end)
      };
      await createPlanTask(p,{adjustedFrom:plan.id});
      await toast("时间已调整，新计划已建立");
    }catch(e){ await toast(`调整失败：${e.message||e}`); }
    await renderPlans();
  }

  async function taskMap(){ try{const t=await A.tasks.list(); return new Map((t||[]).map(x=>[String(x.id),x]));}catch{return new Map();} }
  function statusLabel(s){return({pending:"等待中",running:"触发中",done:"已执行",failed:"失败",canceled:"已取消",cancel_failed:"取消失败"})[s]||s||"未知";}
  async function cancelPlan(plan){
    try{ const ok=await A.tasks.cancel(String(plan.taskId)); await A.db.update("plans",plan.id,{status:ok?"canceled":"cancel_failed",cancelReason:"用户手动取消"}); await toast(ok?"已取消":"没有找到等待中的任务"); }
    catch(e){ await toast(`取消失败：${e.message||e}`); }
    await renderPlans();
  }
  async function deletePlan(plan){
    try{
      if(plan.eventId && plan.characterId){ try{await A.memory.deleteTimeline({characterId:plan.characterId,appEventId:plan.eventId});}catch{} }
      await A.db.delete("plans",plan.id); await toast("记录已删除");
    }catch(e){ await toast(`删除失败：${e.message||e}`); }
    await renderPlans();
  }
  async function clearFinished(){
    try{
      const [plans,tm]=await Promise.all([dbList("plans",500),taskMap()]);
      const rows=(plans||[]).filter(p=>p.version==="0.5"); let n=0;
      for(const p of rows){
        const st=tm.get(String(p.taskId))?.status||p.status;
        if(["done","failed","canceled","cancel_failed"].includes(st)){
          if(p.eventId && p.characterId){ try{await A.memory.deleteTimeline({characterId:p.characterId,appEventId:p.eventId});}catch{} }
          await A.db.delete("plans",p.id); n++;
        }
      }
      await toast(n?`已清理 ${n} 条记录`:"没有可清理的记录"); await renderPlans();
    }catch(e){ await toast(`清理失败：${e.message||e}`); }
  }
  async function renderPlans(){
    const host=$("#plans"); host.innerHTML='<div class="empty">读取中……</div>';
    try{
      const [plans,tm]=await Promise.all([dbList("plans",500),taskMap()]);
      const rows=[...(plans||[])].filter(p=>p.version==="0.5").sort((a,b)=>Date.parse(b.createdAt||0)-Date.parse(a.createdAt||0)).slice(0,50);
      host.innerHTML=""; if(!rows.length){ host.innerHTML='<div class="empty">还没有 v0.5 计划。</div>'; return; }
      for(const p of rows){
        const task=tm.get(String(p.taskId)),status=task?.status||p.status||"unknown";
        const box=document.createElement("div");box.className="plan";
        const top=document.createElement("div");top.className="planTop";
        const name=document.createElement("div");name.className="planName";name.textContent=p.characterName||p.characterId;
        const st=document.createElement("div");st.className="status";st.textContent=statusLabel(status); top.append(name,st);
        const meta=document.createElement("div");meta.className="planMeta";
        const exact=$("#showExact").checked&&p.runAt?`\n测试精确点：${new Date(p.runAt).toLocaleString()}`:"";
        meta.textContent=`来源：${p.sourceText||""}\n起点：${p.anchorTime?new Date(p.anchorTime).toLocaleString():""}\n依据：${p.sourceLabel||""}\n联系窗口：${new Date(p.windowStart).toLocaleString()} ～ ${new Date(p.windowEnd).toLocaleTimeString()}${exact}${task?.lastError?`\n错误：${task.lastError}`:""}`;
        box.append(top,meta);
        const acts=document.createElement("div");acts.className="routeActions";
        if(status==="pending"){
          const adjust=document.createElement("button");adjust.className="tiny";adjust.textContent="调整时间";
          const cancel=document.createElement("button");cancel.className="tiny danger";cancel.textContent="手动取消";cancel.onclick=()=>cancelPlan(p);
          acts.append(adjust,cancel);
          const panel=document.createElement("div");panel.className="adjustBox";panel.hidden=true;
          const startInput=document.createElement("input");startInput.type="datetime-local";startInput.value=dateTimeLocalValue(new Date(p.windowStart));
          const endInput=document.createElement("input");endInput.type="datetime-local";endInput.value=dateTimeLocalValue(new Date(p.windowEnd));
          const save=document.createElement("button");save.className="tiny";save.textContent="保存调整";save.onclick=()=>reschedulePlan(p,startInput.value,endInput.value);
          const close=document.createElement("button");close.className="tiny";close.textContent="收起";close.onclick=()=>panel.hidden=true;
          const inputs=document.createElement("div");inputs.className="row";inputs.append(startInput,endInput);
          const panelActs=document.createElement("div");panelActs.className="routeActions";panelActs.append(save,close);
          panel.append(inputs,panelActs);box.append(panel);
          adjust.onclick=()=>{panel.hidden=!panel.hidden;};
        }else{
          const del=document.createElement("button");del.className="tiny danger";del.textContent="删除记录";del.onclick=()=>deletePlan(p);acts.append(del);
        }
        box.append(acts);host.appendChild(box);
      }
    }catch(e){ host.innerHTML=`<div class="empty">计划读取失败：${e.message||e}</div>`; }
  }

  function switchMode(mode){
    state.mode=mode; $$('.tab').forEach(b=>b.classList.toggle('active',b.dataset.mode===mode)); $$('.modePanel').forEach(p=>p.hidden=true); $("#mode-"+mode).hidden=false;
    if(mode==="auto")estimateAuto(); refreshDefaultTriggerReason();
  }
  function setCustomDefaults(){
    const base=state.anchorTime||new Date(); const now=new Date(); const start=addMin(base,25)>now?addMin(base,25):addMin(now,5); const end=addMin(base,55)>start?addMin(base,55):addMin(start,30);
    $("#customStart").value=dateTimeLocalValue(start); $("#customEnd").value=dateTimeLocalValue(end);
  }
  async function onCharacterChange(){
    state.characterId=$("#character").value; state.selectedMessageIds.clear(); state.anchorTime=null; state.autoTiming=null; state.triggerDirty=false; $("#sourceText").value=""; $("#triggerReason").value="";
    await Promise.all([loadMessages(),loadEvents(),loadRoutes(),renderPlans()]); estimateAuto();
  }

  async function boot(){
    if(!A){document.body.innerHTML='<pre style="padding:20px">未检测到 AiPhone SDK，请在 Float 小手机里运行。</pre>';return;}
    try{
      await loadCharacters(); setCustomDefaults();
      $("#character").onchange=onCharacterChange;
      $("#refreshMessages").onclick=loadMessages;
      $("#refreshPlans").onclick=renderPlans;
      $("#preview").onclick=showPreview;
      $("#schedule").onclick=schedule;
      $("#reEstimate").onclick=()=>{state.lastPreview=null;estimateAuto();};
      $("#resetTrigger").onclick=()=>{state.triggerDirty=false;refreshDefaultTriggerReason(true);};
      $("#triggerReason").oninput=()=>{state.triggerDirty=true;};
      $("#calendarAnchor").onchange=refreshDefaultTriggerReason;
      $("#calendarPreset").onchange=refreshDefaultTriggerReason;
      $("#routeSelect").onchange=()=>{state.selectedRouteId=$("#routeSelect").value;refreshDefaultTriggerReason();};
      $("#routeStatus").onchange=()=>{$("#routeCustomDur").hidden=$("#routeStatus").value!=="custom";refreshDefaultTriggerReason();};
      $("#routeNote").oninput=()=>refreshDefaultTriggerReason();
      $("#saveRoute").onclick=saveRoute;
      $("#cancelRouteEdit").onclick=cancelEditRoute;
      $("#clearFinished").onclick=clearFinished;
      $$('.tab').forEach(b=>b.onclick=()=>switchMode(b.dataset.mode));
      await Promise.all([loadMessages(),loadEvents(),loadRoutes(),renderPlans()]); estimateAuto();
    }catch(e){document.body.innerHTML=`<pre style="padding:20px">启动失败：${e.message||e}</pre>`;}
  }
  boot();
})();
