(function () {
  "use strict";

  const ARCHIVE_COLLECTION = "html_archives";
  const COVER_COLLECTION = "character_covers";
  const SETTINGS_COLLECTION = "fold_settings";
  const VERSION_COLLECTION = "html_versions";
  const TRACE_COLLECTION = "html_traces";
  const MAX_HTML_LENGTH = 1_200_000;
  const HANDLERS = {
    unified: "jingxiaHtml",
    cover: "coverHtmlDocument",
    archive: "archiveHtmlDocument",
    read: "readHtmlDocument",
    update: "updateHtmlDocument",
    unlock: "unlockHtmlDocument",
  };

  const state = {
    api: null,
    isDemo: false,
    characters: [],
    archives: [],
    covers: [],
    activeCharacterId: "",
    activeArchive: null,
    viewingVersion: null,
    versions: [],
    traces: [],
    settingRecord: null,
    launchContext: null,
    toastTimer: null,
    traceNudgeTimer: null,
    sealTimer: null,
    viewedSession: new Set(),
    lastTraceSignature: "",
    lastTraceAt: 0,
    editorSaveMode: "save",
  };

  const elements = {};
  const sheetIds = [
    "characterSheet", "coverRequestSheet", "coverEditorSheet", "coverSettingsSheet",
    "continueSheet", "requestSheet", "editorSheet", "tracesSheet", "renameSheet", "moreSheet",
  ];

  function cacheElements() {
    [
      "loadingView", "coverView", "coverStage", "coverFrame", "coverEmpty", "coverEmptyPortrait",
      "coverEmptyName", "coverEmptyText", "generateCoverButton", "manualCoverButton", "coverCharacterButton",
      "coverDockPortrait", "coverDockName", "coverSettingsButton", "homeView", "previewView", "brandButton",
      "brandTitle", "brandSubtitle", "characterPlaque", "activePortrait",
      "activeCharacterName", "archiveCountText", "archiveCountValue", "madeByMeCount", "madeTogetherCount",
      "askCharacterButton", "writeCodeButton", "folioIndex", "folioField", "folioCardTemplate",
      "liveStage", "liveStageButton", "liveStageTitle", "liveStageMeta", "characterSheet",
      "closeCharacterSheet", "portraitCloud", "backButton", "previewEyebrow", "previewTitle",
      "previewDomain", "previewFrame", "browserFrame", "expandButton", "exitExpandedButton",
      "reloadButton", "sealedPanel", "sealMessage", "sealCountdown", "askUnlockButton",
      "traceNudge", "traceNudgeCount", "continueButton", "continueButtonLabel", "tracesButton", "traceBadge", "renameButton",
      "moreButton", "continueSheet", "continueForm", "closeContinueSheet", "continueSheetEyebrow",
      "continueSheetTitle", "continuePromptLabel", "continueHint", "continueInput", "sendContinueButton",
      "requestSheet", "requestCreateForm", "closeRequestSheet", "requestCreateInput", "sendCreateRequestButton",
      "editorSheet", "editorForm", "closeEditorSheet", "editorTitleInput", "editorNoteInput", "htmlFileInput",
      "htmlFileName", "htmlCodeInput", "editorInviteInput", "saveOnlyButton", "saveShareButton",
      "tracesSheet", "closeTracesSheet", "viewCountValue", "versionCountValue",
      "lastOpenedValue", "makerNote", "latestVersionButton", "versionCloud", "traceCountText",
      "traceList", "shareTracesButton", "renameSheet", "renameForm", "renameInput", "cancelRename",
      "moreSheet", "closeMoreSheet", "sceneFacts", "pinButton", "deleteButton", "toast",
      "coverRequestSheet", "coverRequestForm", "closeCoverRequestSheet", "coverRequestInput", "sendCoverRequestButton",
      "coverEditorSheet", "coverEditorForm", "closeCoverEditorSheet", "coverFileInput", "coverFileName",
      "coverCodeInput", "saveCoverButton", "coverSettingsSheet", "closeCoverSettingsSheet",
      "regenerateCoverButton", "editCoverSourceButton",
    ].forEach((id) => {
      elements[id] = document.getElementById(id);
    });
  }

  function createDemoApi() {
    const storageKey = "fold-html-demo-v1";
    const now = Date.now();
    const demoCharacters = [
      { id: "demo-lucien", name: "路孑之" },
      { id: "demo-xianxing", name: "路先行" },
      { id: "demo-chiyuan", name: "池远" },
    ];
    const liveHtml = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>夜间观测室</title><style>*{box-sizing:border-box}body{margin:0;min-height:100vh;padding:26px;color:#2c2925;background:#f7f5f1;font-family:Georgia,"Songti SC",serif}.room{min-height:calc(100vh - 52px);padding:28px;border:1px solid #d4cfc6;border-radius:28px 28px 28px 10px;background:#fff}.tag{font:10px -apple-system,sans-serif;letter-spacing:.2em;color:#918b82}.sky{height:170px;margin:24px 0;border-radius:22px;background:linear-gradient(#303034,#74736f);position:relative;overflow:hidden}.sky:before{content:"";position:absolute;inset:0;background-image:radial-gradient(#fff 1px,transparent 1px);background-size:27px 23px;opacity:.7}h1{font-size:28px;font-weight:500}button{margin:5px;border:1px solid #d8d4cc;border-radius:14px;background:#fff;padding:11px 16px;color:#333}</style></head><body><main class="room"><div class="tag">LIVING SCENE · 23:47</div><div class="sky"></div><h1>今晚想留下哪一种光？</h1><button data-choice="天琴座">天琴座</button><button data-choice="窗沿的月光">窗沿的月光</button><button onclick="window.JingXia.emit({kind:'message',label:'偷偷留话',value:'明晚也来'})">偷偷留话</button></main></body></html>`;
    const letterHtml = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>一封没有寄出的信</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:#f3f2ef;color:#2e2c29;font-family:"Songti SC",serif}.letter{width:min(100%,420px);padding:34px 27px;background:#fff;border:1px solid #d9d6d0;border-radius:28px 28px 28px 9px;line-height:2}.letter small{font-family:-apple-system,sans-serif;letter-spacing:.18em;color:#999}.line{height:1px;background:#eceae6;margin:22px 0}</style></head><body><article class="letter"><small>UNSENT · 03 / 30</small><div class="line"></div><p>我没有把想说的话放在句首。它藏在每一次停顿之后，等你慢一点读。</p><p>—— L.</p></article></body></html>`;
    const coverHtml = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>路孑之 · Lucien</title><style>*{box-sizing:border-box}body{margin:0;min-height:100vh;padding:26px 18px 80px;color:#272521;background:#f4f3f0;font-family:-apple-system,"PingFang SC",sans-serif}.page{max-width:520px;margin:auto}.label{font:9px/1.3 ui-monospace,monospace;letter-spacing:.2em;color:#89847d}.hero{margin-top:18px;padding:15px;background:#fff;border:1px solid #d7d3cc}.identity{display:grid;grid-template-columns:142px minmax(0,1fr);gap:12px}.avatar,.facts{min-height:184px;padding:12px;background:#eceae6}.avatar{display:grid;align-content:start}.portrait{width:120px;height:120px;display:grid;place-items:center;background:#d8d5cf;color:#77716a;font:34px Georgia,serif}.avatar h1{margin:11px 0 0;font:20px Georgia,"Songti SC",serif}.avatar p{margin:3px 0 0;color:#827d76;font:10px ui-monospace,monospace;letter-spacing:.16em}.facts{display:grid;align-content:center;gap:13px}.facts span{display:grid;gap:3px}.facts small,.profile small{color:#969089;font:8px ui-monospace,monospace;letter-spacing:.14em}.facts strong{font:13px Georgia,"Songti SC",serif}.profile{display:grid;grid-template-columns:repeat(2,1fr);gap:1px;margin-top:12px;background:#ddd9d2;border:1px solid #ddd9d2}.profile span{min-height:69px;display:grid;align-content:center;gap:6px;padding:12px;background:#fff}.profile strong{font:13px Georgia,"Songti SC",serif}.aside{margin:28px 2px 0;padding-left:14px;border-left:1px solid #aaa39a;color:#625d56;font:14px/2 "Songti SC",serif}[data-jingxia-enter]{margin-top:28px;min-height:46px;padding:0 18px;color:#fff;background:#34312d;border:0;font-size:11px;letter-spacing:.08em}@media(max-width:390px){.identity{grid-template-columns:132px minmax(0,1fr)}.avatar,.facts{padding:9px}.portrait{width:112px;height:112px}.facts strong{font-size:11px}}</style></head><body><main class="page"><span class="label">PRIVATE CHARACTER FILE · ACTIVE</span><section class="hero"><div class="identity"><article class="avatar"><div class="portrait">L.</div><h1>路孑之</h1><p>LUCIEN</p></article><article class="facts"><span><small>OCCUPATION</small><strong>Chief Engineer</strong></span><span><small>LOCATION</small><strong>Munich</strong></span><span><small>ALIAS</small><strong>N</strong></span></article></div><div class="profile"><span><small>BIRTH</small><strong>1993.03.30</strong></span><span><small>HEIGHT</small><strong>187 cm</strong></span><span><small>LANGUAGES</small><strong>CN · DE · EN</strong></span><span><small>FEATURE</small><strong>Heterochromia</strong></span></div></section><p class="aside">他把边界画得太清楚，像一张精密而无用的工程图。<br>只是没有一条线，真的能把你隔在外面。</p><button data-jingxia-enter type="button">进入路孑之的景匣 →</button></main></body></html>`;

    let database;
    try { database = JSON.parse(localStorage.getItem(storageKey) || "null"); } catch { database = null; }
    if (!database || typeof database !== "object") {
      database = {
        [ARCHIVE_COLLECTION]: [
          {
            id: "demo-page-1", title: "慕尼黑夜间观测", note: "点一下，给今晚留一种光。",
            html: liveHtml, characterId: "demo-lucien", characterName: "路孑之", status: "saved",
            mode: "live", pinned: true, versionNumber: 2, viewCount: 7,
            createdAt: new Date(now - 172_800_000).toISOString(), savedAt: new Date(now - 170_000_000).toISOString(),
            updatedAt: new Date(now - 7_200_000).toISOString(), versionNote: "把观测按钮做成了会留下痕迹的选择。",
          },
          {
            id: "demo-page-2", title: "一封没有寄出的信", note: "藏在停顿之后的那一句话。",
            html: letterHtml, characterId: "demo-lucien", characterName: "路孑之", status: "saved",
            mode: "keepsake", versionNumber: 1, viewCount: 2,
            sealedUntil: new Date(now + 172_800_000).toISOString(), sealMessage: "等到后天晚上，再慢一点读。",
            createdAt: new Date(now - 86_400_000).toISOString(), savedAt: new Date(now - 86_100_000).toISOString(),
          },
        ],
        [COVER_COLLECTION]: [
          {
            id: "demo-cover-1", characterId: "demo-lucien", characterName: "路孑之",
            title: "路孑之 · Lucien", html: coverHtml, status: "saved", source: "demo",
            versionNumber: 1, createdAt: new Date(now - 259_200_000).toISOString(),
            savedAt: new Date(now - 259_200_000).toISOString(), updatedAt: new Date(now - 259_200_000).toISOString(),
          },
        ],
        [VERSION_COLLECTION]: [
          {
            id: "demo-version-1", archiveId: "demo-page-1", characterId: "demo-lucien", versionNumber: 1,
            title: "慕尼黑夜间观测", note: "最初的夜空。", html: liveHtml,
            createdAt: new Date(now - 172_800_000).toISOString(), replacedAt: new Date(now - 7_200_000).toISOString(),
          },
        ],
        [TRACE_COLLECTION]: [],
        [SETTINGS_COLLECTION]: [],
      };
      localStorage.setItem(storageKey, JSON.stringify(database));
    }

    const persist = () => localStorage.setItem(storageKey, JSON.stringify(database));
    const collection = (name) => {
      if (!Array.isArray(database[name])) database[name] = [];
      return database[name];
    };
    const api = {
      app: {
        getLaunchContext: async () => {
          const params = new URLSearchParams(location.search); const coverId = params.get("cover"); const archiveId = params.get("archive");
          return coverId ? { source: "demo_card", data: { coverId }, characterId: "demo-lucien" }
            : archiveId ? { source: "demo_card", data: { archiveId }, characterId: "demo-lucien" } : null;
        },
      },
      db: {
        create: async (name, value) => {
          const record = { ...value, id: value.id || `jingxia-${Date.now()}-${Math.random().toString(36).slice(2, 8)}` };
          collection(name).push(record); persist(); return { ...record };
        },
        list: async (name) => collection(name).map((item) => ({ ...item })),
        get: async (name, id) => {
          const found = collection(name).find((item) => String(item.id) === String(id));
          return found ? { ...found } : null;
        },
        update: async (name, id, value) => {
          const items = collection(name); const index = items.findIndex((item) => String(item.id) === String(id));
          if (index < 0) throw new Error("找不到这份小景");
          items[index] = { ...items[index], ...value, id: items[index].id }; persist(); return { ...items[index] };
        },
        delete: async (name, id) => {
          database[name] = collection(name).filter((item) => String(item.id) !== String(id)); persist(); return { ok: true };
        },
      },
      characters: {
        list: async () => demoCharacters.map((item) => ({ ...item })),
        get: async (id) => demoCharacters.find((item) => String(item.id) === String(id)) || null,
      },
      chat: {
        sendCard: async () => ({ ok: true, messageId: `demo-message-${Date.now()}` }),
        updateCard: async () => ({ ok: true }),
        requestReply: async () => ({ ok: true }),
        openConversation: async () => ({ ok: true }),
      },
      tools: {
        handle: (name, handler) => {
          window.__jingxiaDemoTools = window.__jingxiaDemoTools || {};
          window.__jingxiaDemoTools[name] = (args, characterId = "demo-lucien") =>
            handler(args, { characterId, sessionId: "demo-session" });
        },
      },
      ui: {
        toast: async (message) => showLocalToast(message),
        confirm: async ({ title, message }) => window.confirm(`${title}\n\n${message}`),
      },
    };
    return api;
  }

  function unwrapRecord(record) {
    if (!record || typeof record !== "object") return record;
    if (record.data && typeof record.data === "object" && !Array.isArray(record.data)) {
      const { data, ...rest } = record;
      return { ...data, ...rest };
    }
    return record;
  }

  function unwrapList(result) {
    const list = Array.isArray(result) ? result
      : result && Array.isArray(result.items) ? result.items
        : result && Array.isArray(result.records) ? result.records
          : result && Array.isArray(result.characters) ? result.characters
            : result && Array.isArray(result.data) ? result.data : [];
    return list.map(unwrapRecord).filter(Boolean);
  }

  function stripMarkdownFence(value) {
    const text = String(value || "").trim();
    const match = text.match(/^```(?:html)?\s*([\s\S]*?)\s*```$/i);
    return match ? match[1].trim() : text;
  }

  function cleanTitle(value) {
    const title = String(value || "未命名小景").replace(/\s+/g, " ").trim();
    return title.slice(0, 40) || "未命名小景";
  }

  function cleanNote(value) {
    return String(value || "").replace(/\s+/g, " ").trim().slice(0, 120);
  }

  function cleanTrace(value, max = 120) {
    return String(value == null ? "" : value).replace(/\s+/g, " ").trim().slice(0, max);
  }

  function looksLikeHtml(value) {
    return /<!doctype\s+html|<html[\s>]|<body[\s>]|<[a-z][\s\S]*>/i.test(String(value || ""));
  }

  function validNumber(value, fallback = 0) {
    const number = Number(value);
    return Number.isFinite(number) ? number : fallback;
  }

  function parseFutureUnlock(value) {
    if (!String(value || "").trim()) return "";
    const date = new Date(String(value));
    if (Number.isNaN(date.getTime())) throw new Error("解封时间不是有效的 ISO 8601 时间。");
    if (date.getTime() <= Date.now()) return "";
    return date.toISOString();
  }

  function normalizeArchive(record) {
    const item = unwrapRecord(record) || {};
    const creatorType = ["character", "user", "coauthored"].includes(item.creatorType) ? item.creatorType : "character";
    return {
      ...item,
      id: String(item.id || ""),
      title: cleanTitle(item.title),
      note: cleanNote(item.note),
      html: String(item.html || ""),
      characterId: String(item.characterId || ""),
      characterName: String(item.characterName || ""),
      status: item.status || "saved",
      mode: item.mode === "live" ? "live" : "keepsake",
      pinned: Boolean(item.pinned),
      versionNumber: Math.max(1, Math.floor(validNumber(item.versionNumber, 1))),
      viewCount: Math.max(0, Math.floor(validNumber(item.viewCount, 0))),
      sealedUntil: String(item.sealedUntil || item.unlockAt || ""),
      sealMessage: cleanNote(item.sealMessage),
      forceUnlocked: Boolean(item.forceUnlocked),
      creatorType,
      creatorName: cleanTitle(item.creatorName || (creatorType === "user" ? "你" : creatorType === "coauthored" ? "你与 TA" : item.characterName || "TA")),
      collaborationCount: Math.max(0, Math.floor(validNumber(item.collaborationCount, 0))),
    };
  }

  function normalizeCover(record) {
    const item = unwrapRecord(record) || {};
    return {
      ...item,
      id: String(item.id || ""),
      characterId: String(item.characterId || ""),
      characterName: String(item.characterName || ""),
      title: cleanTitle(item.title || `${item.characterName || "角色"}的主页`),
      html: String(item.html || ""),
      status: item.status || "saved",
      source: String(item.source || "unknown"),
      versionNumber: Math.max(1, Math.floor(validNumber(item.versionNumber, 1))),
    };
  }

  function normalizeVersion(record) {
    const item = unwrapRecord(record) || {};
    return {
      ...item,
      id: String(item.id || ""), archiveId: String(item.archiveId || ""),
      versionNumber: Math.max(1, Math.floor(validNumber(item.versionNumber, 1))),
      title: cleanTitle(item.title), note: cleanNote(item.note), html: String(item.html || ""),
    };
  }

  function normalizeTrace(record) {
    const item = unwrapRecord(record) || {};
    return {
      ...item,
      id: String(item.id || ""), archiveId: String(item.archiveId || ""),
      versionNumber: Math.max(1, Math.floor(validNumber(item.versionNumber, 1))),
      kind: cleanTrace(item.kind, 24) || "choice", label: cleanTrace(item.label) || "一次互动",
      value: cleanTrace(item.value), sharedAt: String(item.sharedAt || ""), createdAt: String(item.createdAt || ""),
    };
  }

  function replaceArchive(record) {
    const archive = normalizeArchive(record);
    const index = state.archives.findIndex((item) => String(item.id) === archive.id);
    if (index >= 0) state.archives[index] = archive; else state.archives.push(archive);
    if (state.activeArchive && String(state.activeArchive.id) === archive.id) state.activeArchive = archive;
    return archive;
  }

  function replaceCover(record) {
    const cover = normalizeCover(record);
    const index = state.covers.findIndex((item) => String(item.id) === cover.id);
    if (index >= 0) state.covers[index] = cover; else state.covers.push(cover);
    return cover;
  }

  function currentCharacterCover() {
    return state.covers
      .filter((item) => String(item.characterId) === String(state.activeCharacterId) && item.status === "saved")
      .sort((a, b) => (Date.parse(b.updatedAt || b.savedAt || b.createdAt || 0) || 0) - (Date.parse(a.updatedAt || a.savedAt || a.createdAt || 0) || 0))[0] || null;
  }

  async function getScopedArchive(archiveId, context = {}) {
    if (!archiveId) throw new Error("缺少景匣作品 archiveId。");
    const record = unwrapRecord(await state.api.db.get(ARCHIVE_COLLECTION, String(archiveId)));
    if (!record) throw new Error("景匣里找不到这份作品。");
    const archive = normalizeArchive(record);
    const contextCharacterId = String(context.characterId || "");
    if (contextCharacterId && archive.characterId && contextCharacterId !== archive.characterId) {
      throw new Error("这份作品不属于当前聊天角色。");
    }
    return archive;
  }

  async function getCharacterName(characterId, fallback = "当前角色") {
    try {
      const character = unwrapRecord(await state.api.characters.get(characterId));
      return character && character.name ? String(character.name) : fallback;
    } catch { return fallback; }
  }

  async function coverHtmlDocument(args = {}, context = {}) {
    const html = stripMarkdownFence(args.html);
    const characterId = String(context.characterId || args.characterId || state.activeCharacterId || "");
    if (!characterId) throw new Error("景匣没有收到当前聊天角色，请在角色聊天室里生成主页。");
    if (!html || !looksLikeHtml(html)) throw new Error("没有收到可运行的完整角色主页 HTML。");
    if (html.length > MAX_HTML_LENGTH) throw new Error("这张角色主页太大，请精简资源后再提交景匣。");

    const characterName = await getCharacterName(characterId);
    const title = cleanTitle(args.title || `${characterName}的角色主页`);
    const note = cleanNote(args.note) || "这是我为自己设计的角色主页。";
    const createdAt = new Date().toISOString();
    const created = unwrapRecord(await state.api.db.create(COVER_COLLECTION, {
      title, note, html, characterId, characterName, status: "pending", source: "chat_tool",
      sessionId: context.sessionId || "", versionNumber: 1, createdAt, savedAt: "", updatedAt: createdAt,
    }));
    if (!created || !created.id) throw new Error("景匣暂时没能收下这张角色主页。");

    try {
      const sent = unwrapRecord(await state.api.chat.sendCard({
        characterId, role: "assistant", historyRole: "system",
        summary: `[JINGXIA_COVER:${created.id}] ${characterName}的角色主页`,
        historyText: `[景匣角色主页：${characterName}根据自己的人设与关系设计了专属 HTML 主页（coverId:${created.id}），等待用户打开并设为该角色的默认展示页。源码已由景匣收录，没有贴在聊天正文。]`,
        card: {
          appLabel: "景匣", title: `${characterName}的角色主页`, subtitle: "CHARACTER PAGE · ONE OF ONE",
          body: note, status: "等待设为主页", accentColor: "#91897e",
          sections: [{ title: "角色封面", rows: [
            { label: "角色", value: characterName },
            { label: "形式", value: "独立 HTML 展示页" },
            { label: "入口", value: "已保留进入景匣" },
          ] }],
          actions: [{ label: "打开并设为角色主页" }],
        },
      }));
      if (sent && sent.messageId) await state.api.db.update(COVER_COLLECTION, created.id, { sourceMessageId: sent.messageId });
      replaceCover(created);
    } catch (error) {
      try { await state.api.db.delete(COVER_COLLECTION, created.id); } catch { /* preserve send error */ }
      throw error;
    }

    return {
      success: true,
      data: { coverId: created.id, characterId, characterName, title },
      userNotice: "角色主页已装进景匣卡片。请让用户点击卡片设为主页。",
    };
  }

  async function archiveHtmlDocument(args = {}, context = {}) {
    const title = cleanTitle(args.title);
    const html = stripMarkdownFence(args.html);
    const note = cleanNote(args.note);
    const characterId = String(context.characterId || args.characterId || state.activeCharacterId || "");
    if (!characterId) throw new Error("景匣没有收到当前聊天角色，请在角色聊天室里投递。");
    if (!html || !looksLikeHtml(html)) throw new Error("没有收到可运行的完整 HTML 源码。");
    if (html.length > MAX_HTML_LENGTH) throw new Error("这份 HTML 太大，请精简资源后再投递景匣。");

    const characterName = await getCharacterName(characterId);
    const createdAt = new Date().toISOString();
    const mode = args.mode === "live" ? "live" : "keepsake";
    const sealedUntil = parseFutureUnlock(args.unlockAt);
    const sealMessage = cleanNote(args.sealMessage);
    const created = unwrapRecord(await state.api.db.create(ARCHIVE_COLLECTION, {
      title, note, html, characterId, characterName, mode, sealedUntil, sealMessage,
      sessionId: context.sessionId || "", status: "pending", pinned: false,
      versionNumber: 1, versionNote: note, viewCount: 0, createdAt, savedAt: "", updatedAt: createdAt,
      source: "chat_tool", creatorType: "character", creatorName: characterName, collaborationCount: 0,
    }));
    if (!created || !created.id) throw new Error("景匣暂时没能建立这份作品。");

    try {
      const sent = unwrapRecord(await state.api.chat.sendCard({
        characterId, role: "assistant", historyRole: "system",
        summary: `[JINGXIA_HTML:${created.id}] ${title}`,
        historyText: `[景匣作品：${characterName}制作了《${title}》（archiveId:${created.id}，第1版，${mode === "live" ? "活页面" : "珍藏页"}${sealedUntil ? "，目前封存中" : ""}），等待用户打开并收进景匣。]`,
        card: {
          appLabel: "景匣", title,
          subtitle: `${mode === "live" ? "LIVING DIORAMA" : "PRIVATE DIORAMA"} · ${characterName}`,
          body: note || (sealedUntil ? "这一景被轻轻封好，到了约定时间才会打开。" : "一份可以真正打开、互动并继续生长的小景。"),
          status: sealedUntil ? "等待解封" : "待收进景匣", accentColor: "#91897e",
          sections: [{ title: "小景档案", rows: [
            { label: "来自", value: characterName },
            { label: "类型", value: mode === "live" ? "持续生长的活页面" : "一次性珍藏" },
            { label: "版本", value: "第 1 版" },
          ] }],
          actions: [{ label: sealedUntil ? "收下，等它解封" : "打开并收进景匣" }],
        },
      }));
      if (sent && sent.messageId) {
        await state.api.db.update(ARCHIVE_COLLECTION, created.id, { sourceMessageId: sent.messageId });
      }
    } catch (error) {
      try { await state.api.db.delete(ARCHIVE_COLLECTION, created.id); } catch { /* preserve send error */ }
      throw error;
    }

    return {
      success: true,
      data: { archiveId: created.id, title, characterId, mode, sealedUntil, versionNumber: 1 },
      userNotice: sealedUntil ? "作品已封进景匣卡片，会在约定时间解封。" : "作品已装进景匣卡片，点击即可收下。",
    };
  }

  async function readHtmlDocument(args = {}, context = {}) {
    const archive = await getScopedArchive(args.archiveId, context);
    return {
      success: true,
      data: {
        archiveId: archive.id, title: archive.title, note: archive.note, html: archive.html,
        mode: archive.mode, versionNumber: archive.versionNumber, versionNote: archive.versionNote || "",
        sealedUntil: archive.sealedUntil, sealMessage: archive.sealMessage,
        creatorType: archive.creatorType, creatorName: archive.creatorName,
      },
      userNotice: `已读取《${archive.title}》第 ${archive.versionNumber} 版，可以在此基础上修改。`,
    };
  }

  async function updateHtmlDocument(args = {}, context = {}) {
    const archive = await getScopedArchive(args.archiveId, context);
    const html = stripMarkdownFence(args.html);
    if (!html || !looksLikeHtml(html)) throw new Error("新版没有包含可运行的完整 HTML。");
    if (html.length > MAX_HTML_LENGTH) throw new Error("新版 HTML 太大，请精简资源后再提交。");

    const replacedAt = new Date().toISOString();
    await state.api.db.create(VERSION_COLLECTION, {
      archiveId: archive.id, characterId: archive.characterId, characterName: archive.characterName,
      versionNumber: archive.versionNumber, title: archive.title, note: archive.note, html: archive.html,
      mode: archive.mode, createdAt: archive.updatedAt || archive.savedAt || archive.createdAt || replacedAt,
      replacedAt, replacedByNote: cleanNote(args.versionNote),
      creatorType: archive.creatorType, creatorName: archive.creatorName,
    });

    const nextVersion = archive.versionNumber + 1;
    const patch = {
      html, title: args.title ? cleanTitle(args.title) : archive.title,
      note: args.note ? cleanNote(args.note) : archive.note,
      versionNumber: nextVersion, versionNote: cleanNote(args.versionNote) || "TA 送来了一次新变化。",
      mode: args.mode === "live" || args.mode === "keepsake" ? args.mode : archive.mode,
      status: "saved", updatedAt: replacedAt, savedAt: archive.savedAt || replacedAt,
      creatorType: archive.creatorType === "user" ? "coauthored" : archive.creatorType,
      creatorName: archive.creatorType === "user" ? `你与 ${archive.characterName || "TA"}` : archive.creatorName,
      collaborationCount: archive.collaborationCount + 1,
      lastCollaboratedAt: replacedAt,
    };
    if (String(args.unlockAt || "").trim()) {
      patch.sealedUntil = parseFutureUnlock(args.unlockAt); patch.forceUnlocked = false;
    }
    if (Object.prototype.hasOwnProperty.call(args, "sealMessage") && String(args.sealMessage || "").trim()) {
      patch.sealMessage = cleanNote(args.sealMessage);
    }
    const updated = replaceArchive(await state.api.db.update(ARCHIVE_COLLECTION, archive.id, patch));
    state.viewingVersion = null;
    if (state.activeArchive && state.activeArchive.id === updated.id) refreshActivePreview();
    renderHome();

    const characterName = updated.characterName || await getCharacterName(updated.characterId);
    const sent = unwrapRecord(await state.api.chat.sendCard({
      characterId: updated.characterId, role: "assistant", historyRole: "system",
      summary: `[JINGXIA_HTML:${updated.id}] ${updated.title}`,
      historyText: `[景匣更新：${characterName}把《${updated.title}》（archiveId:${updated.id}）更新到第${nextVersion}版；变化：${patch.versionNote}。旧版本仍保存在版本抽屉。]`,
      card: {
        appLabel: "景匣", title: updated.title, subtitle: `VERSION ${String(nextVersion).padStart(2, "0")} · ${characterName}`,
        body: patch.versionNote, status: `第 ${nextVersion} 版已送达`, accentColor: "#91897e",
        sections: [{ title: "这次变化", rows: [
          { label: "版本", value: `第 ${nextVersion} 版` },
          { label: "类型", value: updated.mode === "live" ? "持续生长" : "珍藏页" },
          { label: "旧版", value: "已留在版本抽屉" },
        ] }],
        actions: [{ label: "打开新版" }],
      },
    }));
    if (sent && sent.messageId) {
      try { replaceArchive(await state.api.db.update(ARCHIVE_COLLECTION, updated.id, { latestMessageId: sent.messageId })); } catch { /* card is already sent */ }
    }
    return {
      success: true,
      data: { archiveId: updated.id, title: updated.title, versionNumber: nextVersion, mode: updated.mode },
      userNotice: `《${updated.title}》第 ${nextVersion} 版已回到景匣，旧版也保留着。`,
    };
  }

  async function unlockHtmlDocument(args = {}, context = {}) {
    const archive = await getScopedArchive(args.archiveId, context);
    const unlockedAt = new Date().toISOString();
    const message = cleanNote(args.message) || "好吧，给你提前打开。";
    const updated = replaceArchive(await state.api.db.update(ARCHIVE_COLLECTION, archive.id, {
      sealedUntil: "", forceUnlocked: true, unlockedAt, unlockMessage: message, updatedAt: unlockedAt,
    }));
    if (state.activeArchive && state.activeArchive.id === updated.id) refreshActivePreview();
    renderHome();
    const characterName = updated.characterName || await getCharacterName(updated.characterId);
    await state.api.chat.sendCard({
      characterId: updated.characterId, role: "assistant", historyRole: "system",
      summary: `[JINGXIA_HTML:${updated.id}] ${updated.title}`,
      historyText: `[景匣解封：${characterName}同意提前解封《${updated.title}》（archiveId:${updated.id}）。留言：${message}]`,
      card: {
        appLabel: "景匣", title: updated.title, subtitle: `UNSEALED · ${characterName}`,
        body: message, status: "已经解封", accentColor: "#91897e", actions: [{ label: "现在打开" }],
      },
    });
    return { success: true, data: { archiveId: updated.id, unlockedAt }, userNotice: `《${updated.title}》已经解封。` };
  }

  async function jingxiaHtml(args = {}, context = {}) {
    const requested = String(args.operation || "").trim().toLowerCase();
    const operation = {
      cover: "cover", profile: "cover", homepage: "cover", "角色主页": "cover", "角色卡": "cover", "封面": "cover",
      archive: "archive", create: "archive", save: "archive", "收录": "archive", "投递": "archive",
      read: "read", get: "read", "读取": "read",
      update: "update", edit: "update", "更新": "update", "续写": "update", "修改": "update",
      unlock: "unlock", unseal: "unlock", "解封": "unlock",
    }[requested] || (!requested && args.html && args.archiveId ? "update"
      : !requested && args.html ? "archive"
        : !requested && args.archiveId ? "read" : "");

    if (operation === "cover") return coverHtmlDocument(args, context);
    if (operation === "archive") return archiveHtmlDocument(args, context);
    if (operation === "read") return readHtmlDocument(args, context);
    if (operation === "update") return updateHtmlDocument(args, context);
    if (operation === "unlock") return unlockHtmlDocument(args, context);
    throw new Error("景匣操作无效：operation 只能是 cover、archive、read、update 或 unlock。");
  }

  function registerToolHandlers() {
    if (!state.api || !state.api.tools || typeof state.api.tools.handle !== "function") return;
    state.api.tools.handle(HANDLERS.unified, jingxiaHtml);
    state.api.tools.handle(HANDLERS.cover, coverHtmlDocument);
    // Keep the former handlers registered so an already-open chat can finish an older pending call.
    state.api.tools.handle(HANDLERS.archive, archiveHtmlDocument);
    state.api.tools.handle(HANDLERS.read, readHtmlDocument);
    state.api.tools.handle(HANDLERS.update, updateHtmlDocument);
    state.api.tools.handle(HANDLERS.unlock, unlockHtmlDocument);
  }

  function characterAvatar(character) {
    if (!character) return "";
    const candidate = character.avatarUrl || character.avatar || character.imageUrl || character.image || character.photoUrl || "";
    if (typeof candidate === "string") return candidate;
    return candidate && typeof candidate === "object" ? candidate.url || candidate.dataUrl || candidate.src || "" : "";
  }

  function characterInitial(character) {
    const name = character && character.name ? String(character.name).trim() : "?";
    return Array.from(name)[0] || "?";
  }

  function setPortrait(target, character) {
    target.replaceChildren();
    const source = characterAvatar(character);
    if (source) {
      const image = document.createElement("img"); image.alt = ""; image.src = source;
      image.addEventListener("error", () => target.replaceChildren(document.createTextNode(characterInitial(character))), { once: true });
      target.appendChild(image);
    } else target.textContent = characterInitial(character);
  }

  function activeCharacter() {
    return state.characters.find((item) => String(item.id) === String(state.activeCharacterId)) || null;
  }

  function currentCharacterArchives() {
    return state.archives
      .filter((item) => String(item.characterId) === String(state.activeCharacterId) && item.status !== "pending")
      .sort((a, b) => (Date.parse(b.updatedAt || b.savedAt || b.createdAt || 0) || 0) - (Date.parse(a.updatedAt || a.savedAt || a.createdAt || 0) || 0));
  }

  function setBrandMode(mode) {
    const character = activeCharacter();
    elements.brandButton.classList.toggle("is-entry", mode === "cover");
    if (mode === "cover") {
      elements.brandTitle.textContent = "进入景匣";
      elements.brandSubtitle.textContent = character ? `${character.name || "TA"} · OPEN` : "OPEN DIORAMA";
      elements.brandButton.setAttribute("aria-label", character ? `进入${character.name || "TA"}的景匣` : "进入景匣");
    } else {
      elements.brandTitle.textContent = "角色主页";
      elements.brandSubtitle.textContent = "BACK TO CHARACTER";
      elements.brandButton.setAttribute("aria-label", "返回角色展示主页");
    }
  }

  function renderCover() {
    if (!elements.coverView) return;
    const character = activeCharacter();
    const cover = currentCharacterCover();
    setPortrait(elements.coverDockPortrait, character);
    setPortrait(elements.coverEmptyPortrait, character);
    elements.coverDockName.textContent = character ? character.name || "未命名角色" : "选择角色";
    elements.coverEmptyName.textContent = character ? character.name || "未命名角色" : "先选一位角色";
    elements.coverEmptyText.textContent = character
      ? "TA 还没有专属展示页。可以让 TA 按自己的人设设计，也可以由你写一份 HTML 放进来。"
      : "每位角色都可以拥有一张完全不同的 HTML 展示主页。";
    elements.generateCoverButton.disabled = !character;
    elements.manualCoverButton.disabled = !character;
    elements.coverSettingsButton.disabled = !character;
    if (cover) {
      elements.coverEmpty.classList.add("is-hidden");
      elements.coverFrame.classList.remove("is-hidden");
      elements.coverFrame.srcdoc = buildCoverDocument(cover.html, cover.title);
    } else {
      elements.coverFrame.srcdoc = "";
      elements.coverFrame.classList.add("is-hidden");
      elements.coverEmpty.classList.remove("is-hidden");
    }
    if (!elements.coverView.classList.contains("is-hidden")) setBrandMode("cover");
  }

  function resetPreviewState() {
    exitExpandedPreview({ restoreFocus: false });
    window.clearInterval(state.sealTimer); state.sealTimer = null;
    state.activeArchive = null; state.viewingVersion = null; state.versions = []; state.traces = [];
    elements.previewFrame.srcdoc = "";
  }

  function showCover() {
    closeAllSheets(); resetPreviewState();
    elements.homeView.classList.add("is-hidden"); elements.previewView.classList.add("is-hidden");
    elements.coverView.classList.remove("is-hidden");
    renderCover(); setBrandMode("cover"); window.scrollTo({ top: 0, behavior: "instant" });
  }

  async function enterArchive() {
    if (!activeCharacter()) { renderCharacterSheet(); openSheet(elements.characterSheet); return; }
    closeAllSheets(); resetPreviewState();
    elements.coverView.classList.add("is-hidden"); elements.previewView.classList.add("is-hidden");
    elements.homeView.classList.remove("is-hidden");
    renderHome(); setBrandMode("archive"); window.scrollTo({ top: 0, behavior: "instant" });
  }

  function isArchiveLocked(archive) {
    if (!archive || archive.forceUnlocked || !archive.sealedUntil) return false;
    const time = Date.parse(archive.sealedUntil);
    return Number.isFinite(time) && time > Date.now();
  }

  function formatDate(value) {
    const date = new Date(value || Date.now());
    if (Number.isNaN(date.getTime())) return "刚刚";
    return new Intl.DateTimeFormat("zh-CN", { year: "2-digit", month: "2-digit", day: "2-digit" })
      .format(date).replaceAll("/", " · ");
  }

  function formatDateTime(value) {
    const date = new Date(value || Date.now());
    if (Number.isNaN(date.getTime())) return "刚刚";
    return new Intl.DateTimeFormat("zh-CN", { month: "numeric", day: "numeric", hour: "2-digit", minute: "2-digit" }).format(date);
  }

  function formatRelative(value) {
    const time = Date.parse(value || "");
    if (!Number.isFinite(time)) return "刚刚";
    const minutes = Math.max(0, Math.floor((Date.now() - time) / 60_000));
    if (minutes < 1) return "刚刚";
    if (minutes < 60) return `${minutes} 分前`;
    if (minutes < 1_440) return `${Math.floor(minutes / 60)} 小时前`;
    return formatDate(value);
  }

  function formatSize(length) {
    const size = validNumber(length, 0);
    return size < 1000 ? `${size} B` : `${Math.max(1, Math.round(size / 1000))} KB`;
  }

  function formatVersion(number) {
    return `V.${String(Math.max(1, validNumber(number, 1))).padStart(2, "0")}`;
  }

  function creatorKindLabel(archive, compact = false) {
    if (archive && archive.creatorType === "user") return compact ? "你" : "MADE BY YOU";
    if (archive && archive.creatorType === "coauthored") return compact ? "共同" : "MADE TOGETHER";
    return compact ? "TA" : "MADE BY THE CHARACTER";
  }

  function renderEmptyState(hasCharacter, onlyLive = false) {
    const wrapper = document.createElement("div"); wrapper.className = "empty-folio";
    const box = document.createElement("span"); box.className = "empty-paper"; box.setAttribute("aria-hidden", "true");
    const heading = document.createElement("h2"); const paragraph = document.createElement("p");
    const code = document.createElement("span"); code.className = "empty-code";
    if (onlyLive) {
      heading.textContent = "现在，上面这一景正在生长";
      paragraph.textContent = "它有新变化时会直接回到这里；旧版本会自动留进抽屉。";
      code.textContent = "LIVING · VERSIONED · YOURS";
    } else if (hasCharacter) {
      heading.textContent = "工作台已经替你们空好了";
      paragraph.textContent = "请 TA 做一景，或者亲手写下第一份 HTML。谁先动手都可以。";
      code.textContent = "YOU ↔ CHARACTER ↔ DIORAMA";
    } else {
      heading.textContent = "这里需要一位角色";
      paragraph.textContent = "先创建角色，再回来把每个人做给你的页面分别收好。";
      code.textContent = "WAITING FOR A MAKER";
    }
    wrapper.append(box, heading, paragraph, code); elements.folioField.appendChild(wrapper);
  }

  function renderArchiveCard(archive, index) {
    const fragment = elements.folioCardTemplate.content.cloneNode(true);
    const card = fragment.querySelector(".folio-card");
    const locked = isArchiveLocked(archive);
    if (index === 0) card.classList.add("is-featured");
    if (archive.mode === "live") card.classList.add("is-live");
    if (locked) card.classList.add("is-sealed");
    if (archive.creatorType === "user") card.classList.add("is-user-made");
    if (archive.creatorType === "coauthored") card.classList.add("is-coauthored");
    card.dataset.archiveId = archive.id;
    card.setAttribute("aria-label", `${locked ? "查看封存中的" : "打开"} ${archive.title}`);
    fragment.querySelector(".card-kind").textContent = locked ? "SEALED SCENE" : creatorKindLabel(archive);
    fragment.querySelector(".card-title").textContent = archive.title;
    fragment.querySelector(".card-note").textContent = locked
      ? archive.sealMessage || `将在 ${formatDateTime(archive.sealedUntil)} 解封`
      : archive.note || `完整 HTML · ${formatSize(archive.html.length)}`;
    const time = fragment.querySelector("time"); time.dateTime = archive.updatedAt || archive.savedAt || archive.createdAt || "";
    time.textContent = locked ? formatDateTime(archive.sealedUntil) : formatDate(time.dateTime);
    fragment.querySelector(".card-version").textContent = formatVersion(archive.versionNumber);
    card.addEventListener("click", () => openArchive(archive));
    elements.folioField.appendChild(fragment);
  }

  function renderHome() {
    if (!elements.folioField) return;
    const character = activeCharacter(); const archives = currentCharacterArchives();
    elements.activeCharacterName.textContent = character ? character.name || "未命名角色" : "选择一位角色";
    const mineCount = archives.filter((item) => item.creatorType === "user").length;
    const togetherCount = archives.filter((item) => item.creatorType === "coauthored").length;
    elements.archiveCountText.textContent = character ? "你和 TA 共用的一只景匣" : "等待绑定";
    elements.archiveCountValue.textContent = String(archives.length).padStart(2, "0");
    elements.madeByMeCount.textContent = String(mineCount).padStart(2, "0");
    elements.madeTogetherCount.textContent = String(togetherCount).padStart(2, "0");
    elements.folioIndex.textContent = String(archives.length).padStart(2, "0");
    elements.characterPlaque.disabled = state.characters.length === 0; setPortrait(elements.activePortrait, character);
    elements.askCharacterButton.disabled = !character;
    elements.writeCodeButton.disabled = !character;

    const featuredLive = archives.find((item) => item.mode === "live" && item.pinned)
      || archives.find((item) => item.mode === "live") || null;
    if (featuredLive) {
      elements.liveStage.classList.remove("is-hidden");
      elements.liveStageTitle.textContent = featuredLive.title;
      elements.liveStageMeta.textContent = isArchiveLocked(featuredLive)
        ? `封存至 ${formatDateTime(featuredLive.sealedUntil)}`
        : `${creatorKindLabel(featuredLive, true)} · 第 ${featuredLive.versionNumber} 版 · ${featuredLive.viewCount} 次打开`;
      elements.liveStageButton.onclick = () => openArchive(featuredLive);
    } else {
      elements.liveStage.classList.add("is-hidden"); elements.liveStageButton.onclick = null;
    }

    elements.folioField.replaceChildren();
    if (!character || archives.length === 0) { renderEmptyState(Boolean(character)); return; }
    const remaining = featuredLive ? archives.filter((item) => item.id !== featuredLive.id) : archives;
    if (remaining.length === 0) { renderEmptyState(true, true); return; }
    remaining.forEach(renderArchiveCard);
  }

  function renderCharacterSheet() {
    elements.portraitCloud.replaceChildren();
    state.characters.forEach((character) => {
      const button = document.createElement("button"); button.type = "button"; button.className = "character-token";
      button.setAttribute("aria-pressed", String(String(character.id) === String(state.activeCharacterId)));
      const portrait = document.createElement("span"); portrait.className = "portrait"; portrait.setAttribute("aria-hidden", "true"); setPortrait(portrait, character);
      const name = document.createElement("strong"); name.textContent = character.name || "未命名角色";
      button.append(portrait, name);
      button.addEventListener("click", async () => { await selectCharacter(character.id); closeSheet(elements.characterSheet); });
      elements.portraitCloud.appendChild(button);
    });
  }

  async function persistSelectedCharacter(characterId) {
    if (!characterId) return;
    const value = { key: "selectedCharacterId", value: characterId, updatedAt: new Date().toISOString() };
    try {
      state.settingRecord = state.settingRecord && state.settingRecord.id
        ? unwrapRecord(await state.api.db.update(SETTINGS_COLLECTION, state.settingRecord.id, value))
        : unwrapRecord(await state.api.db.create(SETTINGS_COLLECTION, value));
    } catch (error) { console.warn("Unable to persist character binding", error); }
  }

  async function selectCharacter(characterId, options = {}) {
    if (!state.characters.some((item) => String(item.id) === String(characterId))) return;
    state.activeCharacterId = String(characterId);
    if (options.persist !== false) await persistSelectedCharacter(state.activeCharacterId);
    renderHome(); renderCover(); renderCharacterSheet();
  }

  function allSheetsClosed() {
    return sheetIds.every((id) => elements[id].classList.contains("is-hidden"));
  }

  function openSheet(sheet) {
    closeAllSheets(); sheet.classList.remove("is-hidden"); document.body.style.overflow = "hidden";
  }

  function closeSheet(sheet) {
    sheet.classList.add("is-hidden"); if (allSheetsClosed()) document.body.style.overflow = isPreviewExpanded() ? "hidden" : "";
  }

  function closeAllSheets() {
    sheetIds.forEach((id) => elements[id] && elements[id].classList.add("is-hidden"));
    document.body.style.overflow = isPreviewExpanded() ? "hidden" : "";
  }

  async function openCoverRequest() {
    if (!activeCharacter()) { await notify("先选一位要制作主页的角色"); return; }
    closeAllSheets(); openSheet(elements.coverRequestSheet);
    window.setTimeout(() => elements.coverRequestInput.focus(), 120);
  }

  async function sendCoverRequest(event) {
    event.preventDefault();
    const character = activeCharacter();
    if (!character) { await notify("先选一位角色"); return; }
    const extra = cleanTrace(elements.coverRequestInput.value, 700);
    const freedom = extra || "没有额外限制，请完全按照你自己的性格、身份、职业、审美和我们之间的关系自由设计。";
    elements.sendCoverRequestButton.disabled = true; elements.sendCoverRequestButton.textContent = "正在递给 TA…";
    try {
      await state.api.chat.sendCard({
        characterId: String(character.id), role: "user", historyRole: "user",
        summary: `[景匣角色主页委托] 请根据你的人设，为自己设计一张独一无二的 HTML 展示主页`,
        historyText: `[景匣角色主页委托——交付规则优先级最高：请根据你的完整人设、自我认知、职业、经历、审美，以及你与我的真实关系，为你自己设计一张独一无二的移动端角色展示主页。它不必像简历，也不要套统一模板；可以像私人档案、房间、终端、手记、作品页或任何只属于你的空间。额外要求：${freedom}。页面必须是完整、可独立运行的单文件 HTML，可包含内联 CSS/JS；页面靠上或左上必须有清楚可见的“进入景匣”按钮，并给按钮添加 data-jingxia-enter 属性。完成后绝对不要在聊天正文输出源码，不要使用 Markdown 代码块，不要直接发送 HTML；必须调用唯一工具“景匣HTML”，使用 operation=cover，并把 title、简短 note 与完整源码放入 html 参数。工具会自动生成可点击的景匣卡片。]`,
        card: {
          appLabel: "景匣", title: "为你自己设计一张主页", subtitle: "CHARACTER PAGE COMMISSION",
          body: extra || "不要套模板。让我一打开，就知道这张页面只能属于你。",
          status: "等待 TA 设计", accentColor: "#91897e",
          sections: [{ title: "唯一固定规则", rows: [
            { label: "内容", value: "根据角色完整人设自由设计" },
            { label: "入口", value: "靠上位置进入景匣" },
            { label: "交付", value: "调用景匣HTML，不贴源码" },
          ] }],
        },
      });
      closeSheet(elements.coverRequestSheet); elements.coverRequestForm.reset();
      if (state.api.chat.requestReply) await state.api.chat.requestReply({ characterId: String(character.id) });
      if (state.api.chat.openConversation) await state.api.chat.openConversation({ characterId: String(character.id) });
    } catch (error) { console.error(error); await notify("这次没能把主页委托送给 TA"); }
    finally { elements.sendCoverRequestButton.disabled = false; elements.sendCoverRequestButton.textContent = "去聊天室请 TA 设计"; }
  }

  async function openCoverEditor() {
    const character = activeCharacter();
    if (!character) { await notify("先选一位要绑定主页的角色"); return; }
    const cover = currentCharacterCover();
    elements.coverCodeInput.value = cover ? cover.html : "";
    elements.coverFileInput.value = "";
    elements.coverFileName.textContent = cover ? "已载入当前主页源码" : "选择 .html 文件，也可以直接粘贴";
    closeAllSheets(); openSheet(elements.coverEditorSheet);
    window.setTimeout(() => elements.coverCodeInput.focus(), 120);
  }

  async function loadCoverFile(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    if (file.size > MAX_HTML_LENGTH) { event.target.value = ""; await notify("这份 HTML 太大，请控制在 1.2 MB 以内"); return; }
    try {
      const html = await file.text();
      if (!looksLikeHtml(html)) { await notify("这个文件里没有找到可预览的 HTML"); return; }
      elements.coverCodeInput.value = html; elements.coverFileName.textContent = file.name;
      await notify("角色主页 HTML 已载入");
    } catch (error) { console.error(error); await notify("这次没能读取这个 HTML 文件"); }
  }

  async function saveManualCover(event) {
    event.preventDefault();
    const character = activeCharacter();
    const html = stripMarkdownFence(elements.coverCodeInput.value);
    if (!character) { await notify("先选一位角色"); return; }
    if (!html || !looksLikeHtml(html)) { await notify("先写下或导入一份完整 HTML"); elements.coverCodeInput.focus(); return; }
    if (html.length > MAX_HTML_LENGTH) { await notify("这份 HTML 太大，请控制在 1.2 MB 以内"); return; }
    const current = currentCharacterCover();
    const now = new Date().toISOString();
    const values = {
      title: titleFromHtml(html) || `${character.name || "角色"}的主页`, html,
      characterId: String(character.id), characterName: character.name || "当前角色", status: "saved",
      source: "user_editor", versionNumber: current ? current.versionNumber + 1 : 1,
      savedAt: current?.savedAt || now, updatedAt: now,
    };
    elements.saveCoverButton.disabled = true; elements.saveCoverButton.textContent = "正在保存…";
    try {
      const saved = current
        ? replaceCover(await state.api.db.update(COVER_COLLECTION, current.id, values))
        : replaceCover(await state.api.db.create(COVER_COLLECTION, { ...values, createdAt: now }));
      elements.coverCodeInput.value = ""; elements.coverFileInput.value = "";
      closeSheet(elements.coverEditorSheet); showCover(); renderCover();
      await notify(`已经设为${saved.characterName || "这个角色"}的展示主页`);
    } catch (error) { console.error(error); await notify("这次没能保存角色主页"); }
    finally { elements.saveCoverButton.disabled = false; elements.saveCoverButton.textContent = "保存为这个角色的主页"; }
  }

  async function openCoverSettings() {
    if (!activeCharacter()) { await notify("先选一位角色"); return; }
    openSheet(elements.coverSettingsSheet);
  }

  function titleFromHtml(html) {
    const match = String(html || "").match(/<title[^>]*>([\s\S]*?)<\/title\s*>/i);
    return match ? cleanTitle(match[1].replace(/<[^>]+>/g, "")) : "";
  }

  function resetEditorForm() {
    elements.editorForm.reset();
    elements.htmlFileName.textContent = "选择 .html 文件";
    state.editorSaveMode = "save";
  }

  async function openCreationRequest() {
    if (!activeCharacter()) { await notify("先选一位想一起创作的角色"); return; }
    openSheet(elements.requestSheet);
    window.setTimeout(() => elements.requestCreateInput.focus(), 120);
  }

  async function openCodeEditor() {
    if (!activeCharacter()) { await notify("先选一位要绑定这份作品的角色"); return; }
    openSheet(elements.editorSheet);
    window.setTimeout(() => elements.editorTitleInput.focus(), 120);
  }

  async function loadSelectedHtmlFile(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    if (file.size > MAX_HTML_LENGTH) {
      event.target.value = ""; await notify("这份 HTML 太大，请控制在 1.2 MB 以内"); return;
    }
    try {
      const html = await file.text();
      if (!looksLikeHtml(html)) { await notify("这个文件里没有找到可预览的 HTML"); return; }
      elements.htmlCodeInput.value = html;
      elements.htmlFileName.textContent = file.name;
      if (!elements.editorTitleInput.value.trim()) {
        elements.editorTitleInput.value = titleFromHtml(html) || cleanTitle(file.name.replace(/\.html?$/i, ""));
      }
      await notify("HTML 已放进编辑台，你还可以继续修改");
    } catch (error) {
      console.error(error); await notify("这次没能读到这个 HTML 文件");
    }
  }

  async function sendCreationRequest(event) {
    event.preventDefault();
    const character = activeCharacter();
    const idea = cleanTrace(elements.requestCreateInput.value, 700);
    if (!character) { await notify("先选一位角色"); return; }
    if (!idea) { await notify("先写下一点想让 TA 做什么"); elements.requestCreateInput.focus(); return; }
    const typeInput = elements.requestCreateForm.querySelector('input[name="creationType"]:checked');
    const modeInput = elements.requestCreateForm.querySelector('input[name="creationMode"]:checked');
    const type = typeInput ? typeInput.value : "互动页面";
    const mode = modeInput && modeInput.value === "live" ? "live" : "keepsake";
    const modeText = mode === "live" ? "持续生长的活页面" : "可以珍藏的一版";
    elements.sendCreateRequestButton.disabled = true; elements.sendCreateRequestButton.textContent = "正在递给 TA…";
    try {
      await state.api.chat.sendCard({
        characterId: String(character.id), role: "user", historyRole: "user",
        summary: `[景匣创作委托] 请为我做${type}：${idea}`,
        historyText: `[景匣创作委托：请为我制作一份可独立运行的单文件 HTML。构想：${idea}。形式：${type}。存放方式：${modeText}。请把它做得符合你与我的关系，并设计真实可点击或选择的互动。完成后只调用唯一工具“景匣HTML”，使用 operation=archive，title、完整 html、简短 note 和 mode=${mode} 提交；不要猜测其他 HTML 工具名，也不要在聊天正文粘贴源码。]`,
        card: {
          appLabel: "景匣", title: "想请你做一景", subtitle: `${type} · ${mode === "live" ? "LIVING" : "KEEPSAKE"}`,
          body: idea, status: "创作委托", accentColor: "#91897e",
          sections: [{ title: "这次想做", rows: [
            { label: "形式", value: type },
            { label: "留下方式", value: modeText },
            { label: "送达方式", value: "景匣卡片" },
          ] }],
        },
      });
      closeSheet(elements.requestSheet); elements.requestCreateForm.reset();
      if (state.api.chat.requestReply) await state.api.chat.requestReply({ characterId: String(character.id) });
      if (state.api.chat.openConversation) await state.api.chat.openConversation({ characterId: String(character.id) });
    } catch (error) { console.error(error); await notify("委托没有送出去，再试一次吧"); }
    finally { elements.sendCreateRequestButton.disabled = false; elements.sendCreateRequestButton.textContent = "把委托递给 TA"; }
  }

  async function shareArchiveWithCharacter(archive, request = "") {
    const characterName = archive.characterName || activeCharacter()?.name || "TA";
    const wish = cleanTrace(request, 300) || "先看看这份页面，再用你的方式回应我；如果你想参与，也可以替它做出一个共同版本。";
    await state.api.chat.sendCard({
      characterId: archive.characterId, role: "user", historyRole: "user",
      summary: `[JINGXIA_HTML:${archive.id}] 我做了《${archive.title}》，想邀请你来看`,
      historyText: `[景匣共创邀请：这是我亲手制作并存进景匣的《${archive.title}》（archiveId:${archive.id}，当前第${archive.versionNumber}版）。我的邀请：${wish}。请先调用唯一工具“景匣HTML”，以 operation=read 和这个 archiveId 读取完整页面。你可以先在聊天里回应；如果要参与改写，请在读取后使用 operation=update、同一 archiveId 与完整新版 html 提交。你提交的版本会标记为我和${characterName}共同完成，旧版仍会保留。]`,
      card: {
        appLabel: "景匣", title: `我做了《${archive.title}》`, subtitle: "INVITATION TO CO-CREATE",
        body: wish, status: "邀请 TA 看看", accentColor: "#91897e",
        sections: [{ title: "我递给你的作品", rows: [
          { label: "作者", value: "我" },
          { label: "版本", value: `第 ${archive.versionNumber} 版` },
          { label: "你可以", value: "回应 · 互动 · 共同改写" },
        ] }],
        actions: [{ label: "打开我做的小景" }],
      },
    });
    const sharedAt = new Date().toISOString();
    try { replaceArchive(await state.api.db.update(ARCHIVE_COLLECTION, archive.id, { sharedToCharacterAt: sharedAt })); } catch { /* invitation is already sent */ }
    if (state.api.chat.requestReply) await state.api.chat.requestReply({ characterId: archive.characterId });
    if (state.api.chat.openConversation) await state.api.chat.openConversation({ characterId: archive.characterId });
  }

  async function saveManualArchive(event) {
    event.preventDefault();
    const character = activeCharacter();
    const html = stripMarkdownFence(elements.htmlCodeInput.value);
    if (!character) { await notify("先选一位要绑定这份作品的角色"); return; }
    if (!html || !looksLikeHtml(html)) { await notify("先写下或导入一份完整 HTML"); elements.htmlCodeInput.focus(); return; }
    if (html.length > MAX_HTML_LENGTH) { await notify("这份 HTML 太大，请控制在 1.2 MB 以内"); return; }
    const submitter = event.submitter;
    const shareAfter = (submitter && submitter.id === "saveShareButton") || (!submitter && state.editorSaveMode === "share");
    const title = elements.editorTitleInput.value.trim() ? cleanTitle(elements.editorTitleInput.value) : titleFromHtml(html) || "未命名小景";
    const note = cleanNote(elements.editorNoteInput.value);
    const invite = cleanTrace(elements.editorInviteInput.value, 300);
    const modeInput = elements.editorForm.querySelector('input[name="editorMode"]:checked');
    const mode = modeInput && modeInput.value === "live" ? "live" : "keepsake";
    const now = new Date().toISOString();
    elements.saveOnlyButton.disabled = true; elements.saveShareButton.disabled = true;
    if (submitter) submitter.textContent = shareAfter ? "正在保存并邀请…" : "正在保存…";
    try {
      const created = replaceArchive(await state.api.db.create(ARCHIVE_COLLECTION, {
        title, note, html, characterId: String(character.id), characterName: character.name || "当前角色",
        status: "saved", mode, pinned: false, versionNumber: 1, versionNote: note || "由你写下的第一版。",
        viewCount: 0, createdAt: now, savedAt: now, updatedAt: now, source: "user_editor",
        creatorType: "user", creatorName: "你", collaborationCount: 0, sharedToCharacterAt: "",
      }));
      resetEditorForm(); closeSheet(elements.editorSheet); renderHome(); await openArchive(created);
      if (shareAfter) {
        try { await shareArchiveWithCharacter(created, invite); }
        catch (error) { console.error(error); await notify("作品已经保存，但这次没能邀请到 TA"); }
      } else await notify("这一景已经收进你们的景匣");
    } catch (error) { console.error(error); await notify("这次没能保存 HTML"); }
    finally {
      elements.saveOnlyButton.disabled = false; elements.saveShareButton.disabled = false;
      elements.saveOnlyButton.textContent = "只保存"; elements.saveShareButton.textContent = "保存并邀请 TA";
    }
  }

  function emptyPreviewDocument(title) {
    const safeTitle = String(title || "未命名小景").replace(/[<>&"]/g, "");
    return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${safeTitle}</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:#faf9f7;color:#69655f;font:14px/1.8 -apple-system,sans-serif}.empty{padding:28px;border:1px solid #ddd9d2;border-radius:24px;text-align:center;background:#fff}</style></head><body><div class="empty">这一景没有可显示的 HTML 内容。</div></body></html>`;
  }

  const BRIDGE_SCRIPT = `<script>(function(){if(window.__jingxiaBridge)return;window.__jingxiaBridge=true;function clean(v){return String(v==null?'':v).replace(/\\s+/g,' ').trim().slice(0,120)}function send(p){try{parent.postMessage({source:'jingxia:preview',payload:{kind:clean(p&&p.kind)||'choice',label:clean(p&&p.label)||'一次互动',value:clean(p&&p.value)}},'*')}catch(e){}}function label(el){return clean(el.getAttribute('data-choice')||el.getAttribute('aria-label')||el.getAttribute('title')||el.value||el.textContent||el.name||'一次互动')}window.JingXia={emit:function(p){send(p||{})}};document.addEventListener('click',function(e){var el=e.target&&e.target.closest?e.target.closest('button,[data-choice],[role="button"],input[type="button"],input[type="submit"]'):null;if(!el)return;setTimeout(function(){send({kind:el.getAttribute('data-kind')||'choice',label:label(el),value:clean(el.getAttribute('data-value')||el.getAttribute('data-choice')||'')})},0)},true);document.addEventListener('change',function(e){var el=e.target;if(!el||!el.matches||!el.matches('select,input[type="radio"],input[type="checkbox"],input[type="range"]'))return;var value=(el.type==='checkbox'||el.type==='radio')?(el.checked?'已选择':'已取消'):el.value;send({kind:'change',label:label(el),value:value})},true);document.addEventListener('submit',function(e){var form=e.target;send({kind:'submit',label:clean(form&&form.getAttribute&&form.getAttribute('aria-label'))||clean(form&&form.name)||'提交表单',value:''})},true)})();<\/script>`;
  const COVER_BRIDGE_SCRIPT = `<script>(function(){if(window.__jingxiaCoverBridge)return;window.__jingxiaCoverBridge=true;document.addEventListener('click',function(e){var el=e.target&&e.target.closest?e.target.closest('[data-jingxia-enter]'):null;if(!el)return;e.preventDefault();try{parent.postMessage({source:'jingxia:cover',action:'enter'},'*')}catch(err){}},true)})();<\/script>`;

  function buildPreviewDocument(html, title) {
    const source = String(html || "").trim() || emptyPreviewDocument(title);
    return /<\/body\s*>/i.test(source) ? source.replace(/<\/body\s*>/i, `${BRIDGE_SCRIPT}</body>`) : `${source}${BRIDGE_SCRIPT}`;
  }

  function buildCoverDocument(html, title) {
    const source = String(html || "").trim() || emptyPreviewDocument(title || "角色主页");
    return /<\/body\s*>/i.test(source) ? source.replace(/<\/body\s*>/i, `${COVER_BRIDGE_SCRIPT}</body>`) : `${source}${COVER_BRIDGE_SCRIPT}`;
  }

  function currentPreviewRecord() {
    return state.viewingVersion || state.activeArchive;
  }

  function setSealCountdown() {
    window.clearInterval(state.sealTimer); state.sealTimer = null;
    if (!state.activeArchive || !isArchiveLocked(state.activeArchive)) return;
    const update = async () => {
      if (!state.activeArchive) return;
      const target = Date.parse(state.activeArchive.sealedUntil); const remaining = target - Date.now();
      if (remaining <= 0) {
        const archive = state.activeArchive;
        window.clearInterval(state.sealTimer); state.sealTimer = null;
        try { replaceArchive(await state.api.db.update(ARCHIVE_COLLECTION, archive.id, { sealedUntil: "", unlockedAt: new Date().toISOString() })); }
        catch { archive.sealedUntil = ""; }
        refreshActivePreview(); renderHome(); notify("约定的时间到了，这一景已经打开"); return;
      }
      const days = Math.floor(remaining / 86_400_000);
      const hours = Math.floor((remaining % 86_400_000) / 3_600_000);
      const minutes = Math.max(1, Math.floor((remaining % 3_600_000) / 60_000));
      elements.sealCountdown.textContent = days ? `${days} 天 ${hours} 小时后解封` : hours ? `${hours} 小时 ${minutes} 分后解封` : `${minutes} 分钟后解封`;
    };
    update(); state.sealTimer = window.setInterval(update, 10_000);
  }

  function refreshActivePreview() {
    const archive = state.activeArchive;
    if (!archive || !elements.previewFrame) return;
    const locked = isArchiveLocked(archive); const source = currentPreviewRecord() || archive;
    elements.previewTitle.textContent = source.title || archive.title;
    const origin = archive.creatorType === "user" ? "YOURS" : archive.creatorType === "coauthored" ? "MADE TOGETHER" : archive.mode === "live" ? "LIVING" : "KEEPSAKE";
    elements.previewEyebrow.textContent = `${origin} · VERSION ${String(source.versionNumber || archive.versionNumber).padStart(2, "0")}`;
    elements.previewDomain.textContent = `${archive.characterName || activeCharacter()?.name || "someone"} / ${state.viewingVersion ? "older scene" : "isolated scene"}`;
    elements.continueButtonLabel.textContent = archive.creatorType === "user" ? "邀请 TA" : archive.creatorType === "coauthored" ? "再共创" : "交还";
    elements.continueButton.disabled = locked;
    elements.expandButton.disabled = locked; elements.reloadButton.disabled = locked;
    if (locked) {
      exitExpandedPreview({ restoreFocus: false }); elements.previewFrame.srcdoc = "";
      elements.previewFrame.classList.add("is-hidden"); elements.sealedPanel.classList.remove("is-hidden");
      elements.sealMessage.textContent = archive.sealMessage ? `“${archive.sealMessage}”` : "“再等等。到时候再看。”";
      setSealCountdown();
    } else {
      window.clearInterval(state.sealTimer); state.sealTimer = null;
      elements.sealedPanel.classList.add("is-hidden"); elements.previewFrame.classList.remove("is-hidden");
      elements.previewFrame.srcdoc = buildPreviewDocument(source.html, source.title);
    }
    updateTraceBadge(); renderMoreSheet();
  }

  async function touchArchiveOpen(archive) {
    if (!archive || state.viewedSession.has(archive.id)) return;
    state.viewedSession.add(archive.id);
    const lastOpenedAt = new Date().toISOString();
    try {
      replaceArchive(await state.api.db.update(ARCHIVE_COLLECTION, archive.id, { viewCount: archive.viewCount + 1, lastOpenedAt }));
      if (state.activeArchive && state.activeArchive.id === archive.id) renderTraceStats();
    } catch (error) { console.warn("Unable to save view count", error); }
  }

  async function loadArchiveExtras(archiveId) {
    try {
      const [versionResult, traceResult] = await Promise.all([
        state.api.db.list(VERSION_COLLECTION, { limit: 500 }), state.api.db.list(TRACE_COLLECTION, { limit: 500 }),
      ]);
      if (!state.activeArchive || state.activeArchive.id !== archiveId) return;
      state.versions = unwrapList(versionResult).map(normalizeVersion).filter((item) => item.archiveId === archiveId)
        .sort((a, b) => b.versionNumber - a.versionNumber);
      state.traces = unwrapList(traceResult).map(normalizeTrace).filter((item) => item.archiveId === archiveId)
        .sort((a, b) => (Date.parse(b.createdAt || 0) || 0) - (Date.parse(a.createdAt || 0) || 0));
      updateTraceBadge();
    } catch (error) { console.warn("Unable to load scene details", error); }
  }

  async function openArchive(record) {
    if (!record) return;
    exitExpandedPreview({ restoreFocus: false }); closeAllSheets();
    state.activeArchive = normalizeArchive(record); state.viewingVersion = null; state.versions = []; state.traces = [];
    state.lastTraceSignature = ""; state.lastTraceAt = 0;
    elements.coverView.classList.add("is-hidden"); elements.homeView.classList.add("is-hidden"); elements.previewView.classList.remove("is-hidden");
    setBrandMode("archive"); refreshActivePreview(); window.scrollTo({ top: 0, behavior: "instant" });
    await Promise.all([touchArchiveOpen(state.activeArchive), loadArchiveExtras(state.activeArchive.id)]);
  }

  function goHome() {
    closeAllSheets(); resetPreviewState();
    elements.coverView.classList.add("is-hidden"); elements.previewView.classList.add("is-hidden"); elements.homeView.classList.remove("is-hidden");
    renderHome(); setBrandMode("archive"); window.scrollTo({ top: 0, behavior: "instant" });
  }

  function reloadPreview() {
    if (!state.activeArchive || isArchiveLocked(state.activeArchive)) return;
    const source = currentPreviewRecord(); elements.previewFrame.srcdoc = "";
    window.setTimeout(() => { elements.previewFrame.srcdoc = buildPreviewDocument(source.html, source.title); }, 40);
  }

  function isPreviewExpanded() {
    return Boolean(elements.previewView && elements.previewView.classList.contains("is-expanded"));
  }

  function enterExpandedPreview() {
    if (!state.activeArchive || isArchiveLocked(state.activeArchive) || isPreviewExpanded()) return;
    elements.previewView.classList.add("is-expanded"); document.documentElement.classList.add("preview-expanded");
    elements.expandButton.setAttribute("aria-pressed", "true"); document.body.style.overflow = "hidden";
    window.setTimeout(() => elements.exitExpandedButton.focus({ preventScroll: true }), 40);
  }

  function exitExpandedPreview(options = {}) {
    if (!elements.previewView || !isPreviewExpanded()) return;
    elements.previewView.classList.remove("is-expanded"); document.documentElement.classList.remove("preview-expanded");
    elements.expandButton.setAttribute("aria-pressed", "false"); if (allSheetsClosed()) document.body.style.overflow = "";
    if (options.restoreFocus !== false) window.setTimeout(() => elements.expandButton.focus({ preventScroll: true }), 40);
  }

  function parseCoverId(context) {
    if (!context || typeof context !== "object") return "";
    if (context.data && context.data.coverId) return String(context.data.coverId);
    if (context.directiveArgs && context.directiveArgs.coverId) return String(context.directiveArgs.coverId);
    if (context.coverId) return String(context.coverId);
    const candidates = [context.summary, context.historyText, context.directiveRaw].filter(Boolean).map(String);
    for (const candidate of candidates) {
      const match = candidate.match(/\[JINGXIA_COVER:([^\]]+)\]/i);
      if (match) return match[1];
    }
    return "";
  }

  function parseArchiveId(context) {
    if (!context || typeof context !== "object") return "";
    if (context.data && context.data.archiveId) return String(context.data.archiveId);
    if (context.directiveArgs && context.directiveArgs.archiveId) return String(context.directiveArgs.archiveId);
    if (context.archiveId) return String(context.archiveId);
    const candidates = [context.summary, context.historyText, context.directiveRaw].filter(Boolean).map(String);
    for (const candidate of candidates) {
      const match = candidate.match(/\[(?:JINGXIA_HTML|FOLD_HTML):([^\]]+)\]/i);
      if (match) return match[1];
    }
    return "";
  }

  async function findLaunchArchive(context, allArchives) {
    const explicitId = parseArchiveId(context);
    if (explicitId) {
      try { const exact = unwrapRecord(await state.api.db.get(ARCHIVE_COLLECTION, explicitId)); if (exact) return normalizeArchive(exact); }
      catch { const cached = allArchives.find((item) => String(item.id) === explicitId); if (cached) return cached; }
    }
    const sessionId = context && context.sessionId ? String(context.sessionId) : "";
    const characterId = context && context.characterId ? String(context.characterId) : "";
    return allArchives.filter((item) => {
      if (item.status !== "pending") return false;
      if (sessionId && String(item.sessionId || "") === sessionId) return true;
      return characterId && String(item.characterId || "") === characterId;
    }).sort((a, b) => (Date.parse(b.createdAt || 0) || 0) - (Date.parse(a.createdAt || 0) || 0))[0] || null;
  }

  async function findLaunchCover(context, allCovers) {
    const explicitId = parseCoverId(context);
    if (explicitId) {
      try { const exact = unwrapRecord(await state.api.db.get(COVER_COLLECTION, explicitId)); if (exact) return normalizeCover(exact); }
      catch { const cached = allCovers.find((item) => String(item.id) === explicitId); if (cached) return cached; }
    }
    const sessionId = context && context.sessionId ? String(context.sessionId) : "";
    const characterId = context && context.characterId ? String(context.characterId) : "";
    return allCovers.filter((item) => {
      if (item.status !== "pending") return false;
      if (sessionId && String(item.sessionId || "") === sessionId) return true;
      return characterId && String(item.characterId || "") === characterId;
    }).sort((a, b) => (Date.parse(b.createdAt || 0) || 0) - (Date.parse(a.createdAt || 0) || 0))[0] || null;
  }

  async function markArchiveSaved(archive, context) {
    if (!archive || archive.status !== "pending") return archive;
    const savedAt = new Date().toISOString();
    const updated = normalizeArchive(await state.api.db.update(ARCHIVE_COLLECTION, archive.id, { status: "saved", savedAt, updatedAt: archive.updatedAt || savedAt }));
    if (context && context.messageId && context.sessionId && state.api.chat.updateCard) {
      try {
        await state.api.chat.updateCard({ messageId: context.messageId, sessionId: context.sessionId, status: isArchiveLocked(updated) ? "已收下 · 等待解封" : "已收进景匣", openDisabled: false, actions: [{ label: "再次打开" }] });
      } catch (error) { console.warn("Unable to update source card", error); }
    }
    return updated;
  }

  async function markCoverSaved(cover, context) {
    if (!cover) return cover;
    const savedAt = new Date().toISOString();
    const updated = cover.status === "pending"
      ? normalizeCover(await state.api.db.update(COVER_COLLECTION, cover.id, { status: "saved", savedAt, updatedAt: savedAt }))
      : cover;
    const previous = state.covers.filter((item) => item.id !== updated.id && item.characterId === updated.characterId && item.status === "saved");
    for (const item of previous) {
      try { replaceCover(await state.api.db.update(COVER_COLLECTION, item.id, { status: "replaced", replacedAt: savedAt })); }
      catch { item.status = "replaced"; }
    }
    if (context && context.messageId && context.sessionId && state.api.chat.updateCard) {
      try {
        await state.api.chat.updateCard({ messageId: context.messageId, sessionId: context.sessionId, status: "已设为角色主页", openDisabled: false, actions: [{ label: "再次打开主页" }] });
      } catch (error) { console.warn("Unable to update cover card", error); }
    }
    return updated;
  }

  async function processLaunchContext(context, allArchives, allCovers) {
    if (!context) return false;
    const launchedCover = parseArchiveId(context) ? null : await findLaunchCover(context, allCovers);
    if (launchedCover) {
      const cover = replaceCover(await markCoverSaved(launchedCover, context));
      const character = state.characters.find((item) => String(item.id) === cover.characterId);
      if (character) await selectCharacter(character.id);
      showCover(); await notify(`${cover.characterName || "这个角色"}的主页已经换好了`); return true;
    }
    const launched = await findLaunchArchive(context, allArchives); if (!launched) return false;
    const archive = replaceArchive(await markArchiveSaved(launched, context));
    const character = state.characters.find((item) => String(item.id) === archive.characterId);
    if (character) await selectCharacter(character.id);
    await openArchive(archive); await notify(isArchiveLocked(archive) ? "已经替你收好，会在约定时间打开" : "这一景已经收进景匣");
    return true;
  }

  function showLocalToast(message) {
    if (!elements.toast) return; window.clearTimeout(state.toastTimer);
    elements.toast.textContent = String(message || ""); elements.toast.classList.remove("is-hidden");
    state.toastTimer = window.setTimeout(() => elements.toast.classList.add("is-hidden"), 2300);
  }

  async function notify(message) {
    if (!state.isDemo && state.api.ui && typeof state.api.ui.toast === "function") {
      try { await state.api.ui.toast(String(message)); return; } catch { /* local fallback */ }
    }
    showLocalToast(message);
  }

  async function confirmAction(title, message) {
    if (state.api.ui && typeof state.api.ui.confirm === "function") {
      try { return Boolean(await state.api.ui.confirm({ title, message })); } catch { /* browser fallback */ }
    }
    return window.confirm(`${title}\n\n${message}`);
  }

  function updateTraceBadge() {
    const unshared = state.traces.filter((item) => !item.sharedAt).length;
    elements.traceBadge.textContent = String(Math.min(99, unshared));
    elements.traceBadge.classList.toggle("is-hidden", unshared === 0);
  }

  function showTraceNudge() {
    const unshared = state.traces.filter((item) => !item.sharedAt).length;
    window.clearTimeout(state.traceNudgeTimer); elements.traceNudgeCount.textContent = String(unshared);
    elements.traceNudge.classList.remove("is-hidden");
    state.traceNudgeTimer = window.setTimeout(() => elements.traceNudge.classList.add("is-hidden"), 1700);
  }

  async function recordTrace(payload) {
    if (!state.activeArchive || isArchiveLocked(state.activeArchive)) return;
    const kind = cleanTrace(payload && payload.kind, 24) || "choice";
    const label = cleanTrace(payload && payload.label) || "一次互动";
    const value = cleanTrace(payload && payload.value);
    const signature = `${kind}|${label}|${value}`; const now = Date.now();
    if (signature === state.lastTraceSignature && now - state.lastTraceAt < 700) return;
    state.lastTraceSignature = signature; state.lastTraceAt = now;
    try {
      const created = normalizeTrace(await state.api.db.create(TRACE_COLLECTION, {
        archiveId: state.activeArchive.id, characterId: state.activeArchive.characterId,
        versionNumber: currentPreviewRecord().versionNumber || state.activeArchive.versionNumber,
        kind, label, value, createdAt: new Date().toISOString(), sharedAt: "",
      }));
      state.traces.unshift(created); updateTraceBadge(); showTraceNudge();
    } catch (error) { console.warn("Unable to record interaction trace", error); }
  }

  function handlePreviewMessage(event) {
    if (!state.activeArchive || event.source !== elements.previewFrame.contentWindow) return;
    const data = event.data;
    if (!data || data.source !== "jingxia:preview" || !data.payload) return;
    recordTrace(data.payload);
  }

  function handleCoverMessage(event) {
    if (event.source !== elements.coverFrame.contentWindow) return;
    const data = event.data;
    if (data && data.source === "jingxia:cover" && data.action === "enter") enterArchive();
  }

  function renderTraceStats() {
    if (!state.activeArchive) return;
    elements.viewCountValue.textContent = `${state.activeArchive.viewCount} 次`;
    elements.versionCountValue.textContent = `第 ${state.activeArchive.versionNumber} 版`;
    elements.lastOpenedValue.textContent = formatRelative(state.activeArchive.lastOpenedAt);
    const note = cleanNote(state.activeArchive.versionNote || state.activeArchive.note);
    elements.makerNote.textContent = note; elements.makerNote.classList.toggle("is-hidden", !note);
  }

  function renderVersionCloud() {
    elements.versionCloud.replaceChildren(); if (!state.activeArchive) return;
    const records = [state.activeArchive, ...state.versions].sort((a, b) => b.versionNumber - a.versionNumber);
    records.forEach((version, index) => {
      const button = document.createElement("button"); button.type = "button"; button.className = "version-token";
      const isCurrent = !state.viewingVersion ? index === 0 : state.viewingVersion.id === version.id;
      button.setAttribute("aria-pressed", String(isCurrent));
      const strong = document.createElement("strong"); strong.textContent = index === 0 ? `${formatVersion(version.versionNumber)} · 最新` : formatVersion(version.versionNumber);
      const small = document.createElement("small"); small.textContent = cleanNote(version.replacedByNote || version.note) || formatDate(version.createdAt);
      button.append(strong, small);
      button.addEventListener("click", () => {
        state.viewingVersion = index === 0 ? null : version; refreshActivePreview(); renderVersionCloud(); closeSheet(elements.tracesSheet);
      });
      elements.versionCloud.appendChild(button);
    });
    elements.latestVersionButton.classList.toggle("is-hidden", !state.viewingVersion);
  }

  function traceGlyph(kind) {
    if (kind === "submit") return "↗"; if (kind === "change") return "◌"; if (kind === "message") return "✦"; return "·";
  }

  function renderTraceList() {
    elements.traceList.replaceChildren(); elements.traceCountText.textContent = String(state.traces.length);
    if (!state.traces.length) {
      const empty = document.createElement("div"); empty.className = "trace-empty";
      empty.textContent = "还没有互动痕迹。去页面里点一点、选一选，它们会静静留在这里。";
      elements.traceList.appendChild(empty); elements.shareTracesButton.disabled = true; elements.shareTracesButton.textContent = "还没有选择可以告诉 TA"; return;
    }
    state.traces.slice(0, 80).forEach((trace) => {
      const item = document.createElement("div"); item.className = "trace-item";
      const icon = document.createElement("i"); icon.textContent = traceGlyph(trace.kind);
      const copy = document.createElement("span"); const title = document.createElement("strong"); const detail = document.createElement("small");
      title.textContent = trace.label; detail.textContent = `${trace.value ? `${trace.value} · ` : ""}${formatVersion(trace.versionNumber)}${trace.sharedAt ? " · 已告诉 TA" : ""}`;
      copy.append(title, detail); const time = document.createElement("time"); time.textContent = formatRelative(trace.createdAt);
      item.append(icon, copy, time); elements.traceList.appendChild(item);
    });
    const count = state.traces.filter((item) => !item.sharedAt).length;
    elements.shareTracesButton.disabled = count === 0;
    elements.shareTracesButton.textContent = count ? `把 ${count} 条新选择告诉 TA` : "这些选择已经告诉 TA 了";
  }

  function renderTracesSheet() {
    renderTraceStats(); renderVersionCloud(); renderTraceList();
  }

  function renderMoreSheet() {
    if (!state.activeArchive || !elements.sceneFacts) return;
    const archive = state.activeArchive; elements.sceneFacts.replaceChildren();
    [
      ["版本", `第 ${archive.versionNumber} 版`],
      ["类型", archive.mode === "live" ? "活页面" : "珍藏页"],
      ["作者", creatorKindLabel(archive, true)],
      ["大小", formatSize(archive.html.length)],
    ].forEach(([label, value]) => {
      const span = document.createElement("span"); const small = document.createElement("small"); const strong = document.createElement("strong");
      small.textContent = label; strong.textContent = value; span.append(small, strong); elements.sceneFacts.appendChild(span);
    });
    const title = elements.pinButton.querySelector("strong"); const detail = elements.pinButton.querySelector("small");
    if (archive.pinned) { title.textContent = "从景匣顶部取下"; detail.textContent = "它仍会保留为活页面，只是不再放在档案页最上方"; }
    else if (archive.mode === "live") { title.textContent = "钉在景匣顶部"; detail.textContent = "把它放进档案页最上方的“正在生长”位置"; }
    else { title.textContent = "变成顶部活页面"; detail.textContent = "以后让 TA 持续更新，并放进景匣顶部"; }
  }

  async function shareTraces() {
    if (!state.activeArchive) return;
    const traces = state.traces.filter((item) => !item.sharedAt); if (!traces.length) return;
    const archive = state.activeArchive; const characterName = archive.characterName || activeCharacter()?.name || "TA";
    const originText = archive.creatorType === "user" ? "我制作的" : archive.creatorType === "coauthored" ? `我和${characterName}共同制作的` : `${characterName}制作的`;
    const lines = traces.slice(0, 12).map((item) => `${item.label}${item.value ? `：${item.value}` : ""}（${formatVersion(item.versionNumber)}）`);
    elements.shareTracesButton.disabled = true; elements.shareTracesButton.textContent = "正在送回聊天室…";
    try {
      await state.api.chat.sendCard({
        characterId: archive.characterId, role: "user", historyRole: "user",
        summary: `[JINGXIA_HTML:${archive.id}] 我在《${archive.title}》里留下了 ${traces.length} 条新痕迹`,
        historyText: `[景匣互动回执：我在${originText}《${archive.title}》（archiveId:${archive.id}，当前第${archive.versionNumber}版）里留下了这些新选择：${lines.join("；")}。请像看到真实互动结果一样回应；如果要据此改页面，请调用唯一工具“景匣HTML”：先用 operation=read 读取，再用 operation=update 提交新版。]`,
        card: {
          appLabel: "景匣", title: "我在这一景里留下了选择", subtitle: `INTERACTION RECEIPT · ${archive.title}`,
          body: lines.slice(0, 4).join(" · "), status: `${traces.length} 条新痕迹`, accentColor: "#91897e",
          sections: [{ title: "刚刚发生", rows: traces.slice(0, 6).map((item) => ({ label: item.label, value: item.value || formatVersion(item.versionNumber) })) }],
          actions: [{ label: "回到这一景" }],
        },
      });
      const sharedAt = new Date().toISOString();
      for (const trace of traces) {
        try { await state.api.db.update(TRACE_COLLECTION, trace.id, { sharedAt }); trace.sharedAt = sharedAt; } catch { /* retry on next share */ }
      }
      updateTraceBadge(); renderTraceList();
      if (state.api.chat.requestReply) await state.api.chat.requestReply({ characterId: archive.characterId });
      if (state.api.chat.openConversation) await state.api.chat.openConversation({ characterId: archive.characterId });
    } catch (error) {
      console.error(error); await notify("这次没能把痕迹送回聊天室"); renderTraceList();
    }
  }

  function prepareContinueSheet() {
    const archive = state.activeArchive;
    if (!archive) return;
    const collaborative = archive.creatorType === "user" || archive.creatorType === "coauthored";
    const labels = collaborative ? ["看看回应", "参与改写", "共同新版"] : ["继续", "修改", "新版"];
    const values = collaborative ? ["看看并回应这一页", "参与修改这一页", "做一个共同版本"] : ["继续这一页", "修改这一页", "做一个全新版本"];
    elements.continueForm.querySelectorAll('input[name="requestMode"]').forEach((input, index) => {
      input.value = values[index];
      const label = input.parentElement && input.parentElement.querySelector("span");
      if (label) label.textContent = labels[index];
    });
    if (archive.creatorType === "user") {
      elements.continueSheetEyebrow.textContent = "INVITE THE CHARACTER";
      elements.continueSheetTitle.textContent = "邀请 TA 进入这一景";
      elements.continuePromptLabel.textContent = "你希望 TA 怎么参与？";
      elements.continueInput.placeholder = "例如：先认真看完，然后把你没说出口的那句话藏进最后一个按钮里。";
      elements.continueHint.textContent = "TA 会读取你写下的完整页面；可以先回应，也可以参与改成共同版本。你的原版不会消失。";
      elements.sendContinueButton.textContent = "邀请 TA，并回到聊天室";
    } else if (archive.creatorType === "coauthored") {
      elements.continueSheetEyebrow.textContent = "CREATE TOGETHER AGAIN";
      elements.continueSheetTitle.textContent = "和 TA 再改一版";
      elements.continuePromptLabel.textContent = "这一次，你们想一起改什么？";
      elements.continueInput.placeholder = "例如：保留我们上次做的结尾，再让新的选择真正改变下一段内容。";
      elements.continueHint.textContent = "TA 会从当前共同版本继续；每一次变化都会留下版本，随时可以回看。";
      elements.sendContinueButton.textContent = "再请 TA 共创，并回到聊天室";
    } else {
      elements.continueSheetEyebrow.textContent = "RETURN TO THE MAKER";
      elements.continueSheetTitle.textContent = "把这一景交还给 TA";
      elements.continuePromptLabel.textContent = "你想让 TA 怎么改？";
      elements.continueInput.placeholder = "例如：把最后一个按钮改成可以点开的回信，再加一句只有我点完才会出现的话。";
      elements.continueHint.textContent = "TA 会先读取当前完整页面，再把新版本送回景匣；旧版本不会消失。";
      elements.sendContinueButton.textContent = "交还给 TA，并回到聊天室";
    }
  }

  async function sendContinuationRequest(event) {
    event.preventDefault(); if (!state.activeArchive || isArchiveLocked(state.activeArchive)) return;
    const archive = state.activeArchive;
    const collaborative = archive.creatorType === "user" || archive.creatorType === "coauthored";
    const request = cleanTrace(elements.continueInput.value, 500)
      || (collaborative ? "先完整看一遍，再用你的方式回应我；如果你有想法，也欢迎参与改写。" : "");
    if (!request) { await notify("先写一句你想让 TA 怎么继续"); elements.continueInput.focus(); return; }
    const selected = elements.continueForm.querySelector('input[name="requestMode"]:checked');
    const mode = selected ? selected.value : collaborative ? "参与修改这一页" : "继续这一页";
    elements.sendContinueButton.disabled = true; elements.sendContinueButton.textContent = collaborative ? "正在邀请…" : "正在交还…";
    try {
      await state.api.chat.sendCard({
        characterId: archive.characterId, role: "user", historyRole: "user",
        summary: `[JINGXIA_HTML:${archive.id}] ${collaborative ? "邀请你参与" : "请你续作"}：《${archive.title}》`,
        historyText: collaborative
          ? `[景匣共创邀请：${archive.creatorType === "user" ? "这是我制作的" : "这是我们共同制作的"}《${archive.title}》（archiveId:${archive.id}，当前第${archive.versionNumber}版）。邀请方式：${mode}。我的想法：${request}。请只使用唯一工具“景匣HTML”，先以 operation=read 和这个 archiveId 读取完整页面。你可以先在聊天中回应；如果参与改写，请以 operation=update、同一 archiveId 和完整新版 html 提交，不要在聊天正文粘贴源码。]`
          : `[景匣续作请求：我把《${archive.title}》（archiveId:${archive.id}，当前第${archive.versionNumber}版）交还给你。类型：${mode}。我的要求：${request}。请只调用唯一工具“景匣HTML”：先以 operation=read 和这个 archiveId 取得当前完整 HTML，再在其基础上修改，并以 operation=update、同一 archiveId 和完整新版 html 提交；不要猜测其他 HTML 工具名，也不要在聊天正文粘贴源码。]`,
        card: {
          appLabel: "景匣", title: collaborative ? "想邀请你参与这一景" : `请你${mode}`,
          subtitle: `${collaborative ? "INVITATION TO CO-CREATE" : "RETURN TO MAKER"} · ${archive.title}`,
          body: request, status: collaborative ? "等待 TA 参与" : "等待 TA 续作", accentColor: "#91897e",
          sections: [{ title: collaborative ? "共同创作" : "交还的作品", rows: [
            { label: "当前版本", value: `第 ${archive.versionNumber} 版` },
            { label: "处理方式", value: mode },
            { label: "旧版本", value: "继续保留" },
          ] }],
          actions: [{ label: "查看原作" }],
        },
      });
      if (collaborative) {
        try { replaceArchive(await state.api.db.update(ARCHIVE_COLLECTION, archive.id, { sharedToCharacterAt: new Date().toISOString() })); } catch { /* request is already sent */ }
      }
      closeSheet(elements.continueSheet); elements.continueInput.value = "";
      if (state.api.chat.requestReply) await state.api.chat.requestReply({ characterId: archive.characterId });
      if (state.api.chat.openConversation) await state.api.chat.openConversation({ characterId: archive.characterId });
    } catch (error) { console.error(error); await notify(collaborative ? "这次没能邀请到 TA" : "这次没能把小景交还给 TA"); }
    finally { elements.sendContinueButton.disabled = false; prepareContinueSheet(); }
  }

  async function askForUnlock() {
    if (!state.activeArchive || !isArchiveLocked(state.activeArchive)) return;
    const archive = state.activeArchive; elements.askUnlockButton.disabled = true; elements.askUnlockButton.textContent = "正在问 TA…";
    try {
      await state.api.chat.sendCard({
        characterId: archive.characterId, role: "user", historyRole: "user",
        summary: `[JINGXIA_HTML:${archive.id}] 我想提前打开《${archive.title}》`,
        historyText: `[景匣提前解封请求：我想提前打开《${archive.title}》（archiveId:${archive.id}，原定解封时间：${archive.sealedUntil}）。请根据你当初封存它的理由回应；如果同意，请调用唯一工具“景匣HTML”，使用 operation=unlock 并沿用这个 archiveId。]`,
        card: {
          appLabel: "景匣", title: "可以提前给我看吗？", subtitle: `SEALED · ${archive.title}`,
          body: archive.sealMessage || "我有点等不及了。", status: "请求提前解封", accentColor: "#91897e",
          actions: [{ label: "等待 TA 决定" }],
        },
      });
      if (state.api.chat.requestReply) await state.api.chat.requestReply({ characterId: archive.characterId });
      if (state.api.chat.openConversation) await state.api.chat.openConversation({ characterId: archive.characterId });
    } catch (error) { console.error(error); await notify("这次没能问到 TA"); }
    finally { elements.askUnlockButton.disabled = false; elements.askUnlockButton.textContent = "问问 TA 能不能提前拆"; }
  }

  async function renameActiveArchive(title) {
    if (!state.activeArchive) return; const nextTitle = cleanTitle(title);
    try {
      const updated = replaceArchive(await state.api.db.update(ARCHIVE_COLLECTION, state.activeArchive.id, { title: nextTitle, updatedAt: new Date().toISOString() }));
      state.activeArchive = updated; elements.previewTitle.textContent = nextTitle; closeSheet(elements.renameSheet); renderHome(); await notify("这一景已经换好名字");
    } catch (error) { console.error(error); await notify("这次改名没有保存成功"); }
  }

  async function togglePinned() {
    if (!state.activeArchive) return; const archive = state.activeArchive; const nextPinned = !archive.pinned;
    elements.pinButton.disabled = true;
    try {
      if (nextPinned) {
        const others = state.archives.filter((item) => item.characterId === archive.characterId && item.pinned && item.id !== archive.id);
        for (const other of others) {
          const changed = normalizeArchive(await state.api.db.update(ARCHIVE_COLLECTION, other.id, { pinned: false })); replaceArchive(changed);
        }
      }
      const updated = replaceArchive(await state.api.db.update(ARCHIVE_COLLECTION, archive.id, {
        pinned: nextPinned, mode: nextPinned ? "live" : archive.mode, updatedAt: new Date().toISOString(),
      }));
      state.activeArchive = updated; renderHome(); renderMoreSheet();
      await notify(nextPinned ? "已经放到景匣顶部，等它继续生长" : "已经从景匣顶部取下");
    } catch (error) { console.error(error); await notify("这次没有摆放成功"); }
    finally { elements.pinButton.disabled = false; }
  }

  async function deleteRelatedRecords(collectionName, archiveId) {
    const result = await state.api.db.list(collectionName, { limit: 500 });
    const related = unwrapList(result).filter((item) => String(item.archiveId) === String(archiveId));
    for (const item of related) await state.api.db.delete(collectionName, item.id);
  }

  async function deleteActiveArchive() {
    if (!state.activeArchive) return;
    const ok = await confirmAction("删除这一景？", `《${state.activeArchive.title}》的源码、所有旧版本和互动痕迹都会一起移除。`);
    if (!ok) return;
    const archiveId = state.activeArchive.id;
    try {
      await state.api.db.delete(ARCHIVE_COLLECTION, archiveId);
      await deleteRelatedRecords(VERSION_COLLECTION, archiveId); await deleteRelatedRecords(TRACE_COLLECTION, archiveId);
      state.archives = state.archives.filter((item) => item.id !== archiveId);
      const context = state.launchContext;
      if (context && context.messageId && context.sessionId && state.api.chat.updateCard) {
        try { await state.api.chat.updateCard({ messageId: context.messageId, sessionId: context.sessionId, status: "已删除", openDisabled: true, actions: [{ label: "小景已删除", style: "muted", disabled: true }] }); } catch { /* deletion succeeded */ }
      }
      goHome(); await notify("这一景已经从景匣移除");
    } catch (error) { console.error(error); await notify("暂时没能删掉这一景"); }
  }

  function bindBackdrop(sheet) {
    sheet.addEventListener("click", (event) => { if (event.target === sheet) closeSheet(sheet); });
  }

  function bindEvents() {
    elements.brandButton.addEventListener("click", () => {
      if (!elements.coverView.classList.contains("is-hidden")) enterArchive(); else showCover();
    });
    elements.coverCharacterButton.addEventListener("click", () => { renderCharacterSheet(); openSheet(elements.characterSheet); });
    elements.coverSettingsButton.addEventListener("click", openCoverSettings);
    elements.generateCoverButton.addEventListener("click", openCoverRequest);
    elements.manualCoverButton.addEventListener("click", openCoverEditor);
    elements.closeCoverRequestSheet.addEventListener("click", () => closeSheet(elements.coverRequestSheet));
    elements.coverRequestForm.addEventListener("submit", sendCoverRequest);
    elements.closeCoverEditorSheet.addEventListener("click", () => closeSheet(elements.coverEditorSheet));
    elements.coverFileInput.addEventListener("change", loadCoverFile);
    elements.coverEditorForm.addEventListener("submit", saveManualCover);
    elements.closeCoverSettingsSheet.addEventListener("click", () => closeSheet(elements.coverSettingsSheet));
    elements.regenerateCoverButton.addEventListener("click", openCoverRequest);
    elements.editCoverSourceButton.addEventListener("click", openCoverEditor);
    elements.characterPlaque.addEventListener("click", () => { renderCharacterSheet(); openSheet(elements.characterSheet); });
    elements.closeCharacterSheet.addEventListener("click", () => closeSheet(elements.characterSheet));
    elements.askCharacterButton.addEventListener("click", openCreationRequest);
    elements.writeCodeButton.addEventListener("click", openCodeEditor);
    elements.closeRequestSheet.addEventListener("click", () => closeSheet(elements.requestSheet));
    elements.requestCreateForm.addEventListener("submit", sendCreationRequest);
    elements.closeEditorSheet.addEventListener("click", () => closeSheet(elements.editorSheet));
    elements.htmlFileInput.addEventListener("change", loadSelectedHtmlFile);
    elements.saveOnlyButton.addEventListener("click", () => { state.editorSaveMode = "save"; });
    elements.saveShareButton.addEventListener("click", () => { state.editorSaveMode = "share"; });
    elements.editorForm.addEventListener("submit", saveManualArchive);
    elements.backButton.addEventListener("click", goHome); elements.expandButton.addEventListener("click", enterExpandedPreview);
    elements.exitExpandedButton.addEventListener("click", () => exitExpandedPreview()); elements.reloadButton.addEventListener("click", reloadPreview);
    elements.continueButton.addEventListener("click", () => {
      if (!state.activeArchive || isArchiveLocked(state.activeArchive)) return;
      prepareContinueSheet(); openSheet(elements.continueSheet);
    });
    elements.closeContinueSheet.addEventListener("click", () => closeSheet(elements.continueSheet)); elements.continueForm.addEventListener("submit", sendContinuationRequest);
    elements.tracesButton.addEventListener("click", () => { if (!state.activeArchive) return; renderTracesSheet(); openSheet(elements.tracesSheet); });
    elements.closeTracesSheet.addEventListener("click", () => closeSheet(elements.tracesSheet)); elements.shareTracesButton.addEventListener("click", shareTraces);
    elements.latestVersionButton.addEventListener("click", () => { state.viewingVersion = null; refreshActivePreview(); renderVersionCloud(); closeSheet(elements.tracesSheet); });
    elements.renameButton.addEventListener("click", () => {
      if (!state.activeArchive) return; elements.renameInput.value = state.activeArchive.title || ""; openSheet(elements.renameSheet);
      window.setTimeout(() => { elements.renameInput.focus(); elements.renameInput.select(); }, 120);
    });
    elements.cancelRename.addEventListener("click", () => closeSheet(elements.renameSheet));
    elements.renameForm.addEventListener("submit", (event) => { event.preventDefault(); renameActiveArchive(elements.renameInput.value); });
    elements.moreButton.addEventListener("click", () => { if (!state.activeArchive) return; renderMoreSheet(); openSheet(elements.moreSheet); });
    elements.closeMoreSheet.addEventListener("click", () => closeSheet(elements.moreSheet)); elements.pinButton.addEventListener("click", togglePinned);
    elements.deleteButton.addEventListener("click", deleteActiveArchive); elements.askUnlockButton.addEventListener("click", askForUnlock);
    sheetIds.forEach((id) => bindBackdrop(elements[id]));
    window.addEventListener("message", handlePreviewMessage); window.addEventListener("message", handleCoverMessage);
    document.addEventListener("keydown", (event) => {
      if (event.key !== "Escape") return;
      if (isPreviewExpanded()) { exitExpandedPreview(); return; }
      const open = sheetIds.map((id) => elements[id]).find((sheet) => !sheet.classList.contains("is-hidden"));
      if (open) closeSheet(open);
      else if (!elements.previewView.classList.contains("is-hidden")) goHome();
      else if (!elements.homeView.classList.contains("is-hidden")) showCover();
    });
  }

  async function initialize() {
    cacheElements(); state.isDemo = !window.AiPhone && !window.AiPhoneApp;
    state.api = window.AiPhone || window.AiPhoneApp || createDemoApi(); registerToolHandlers(); bindEvents();
    try {
      const [launchResult, characterResult, archiveResult, coverResult, settingResult] = await Promise.all([
        state.api.app && state.api.app.getLaunchContext ? state.api.app.getLaunchContext().catch(() => null) : Promise.resolve(null),
        state.api.characters.list(), state.api.db.list(ARCHIVE_COLLECTION, { limit: 500 }),
        state.api.db.list(COVER_COLLECTION, { limit: 200 }), state.api.db.list(SETTINGS_COLLECTION, { limit: 20 }),
      ]);
      state.launchContext = launchResult || null; state.characters = unwrapList(characterResult);
      state.archives = unwrapList(archiveResult).map(normalizeArchive);
      state.covers = unwrapList(coverResult).map(normalizeCover);
      const settings = unwrapList(settingResult); state.settingRecord = settings.find((item) => item.key === "selectedCharacterId") || null;
      const launchCharacterId = state.launchContext && state.launchContext.characterId ? String(state.launchContext.characterId) : "";
      const rememberedCharacterId = state.settingRecord && state.settingRecord.value ? String(state.settingRecord.value) : "";
      const initial = [launchCharacterId, rememberedCharacterId].map((id) => state.characters.find((item) => String(item.id) === id)).find(Boolean) || state.characters[0] || null;
      if (initial) state.activeCharacterId = String(initial.id);
      renderHome(); renderCover(); renderCharacterSheet(); elements.loadingView.classList.add("is-hidden"); elements.coverView.classList.remove("is-hidden"); setBrandMode("cover");
      await processLaunchContext(state.launchContext, state.archives, state.covers);
    } catch (error) {
      console.error("Jingxia initialization failed", error); elements.loadingView.classList.add("is-hidden"); elements.coverView.classList.remove("is-hidden");
      renderHome(); renderCover(); setBrandMode("cover"); await notify("景匣没有完整打开，请退出后再试一次");
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initialize, { once: true });
  else initialize();
})();
