import os, shutil

keep = {
    'icon-heart.svg', 'icon-comment.svg', 'icon-bookmark.svg', 'icon-eye.svg',
    'icon-filter.svg', 'icon-search.svg', 'icon-kudos.svg', 'icon-share.svg',
    'icon-download.svg', 'icon-user.svg', 'icon-character.svg', 'icon-add.svg',
    'icon-close.svg', 'icon-chevron.svg'
}
assets_dir = '/data/workspace/ao3-novel-app/assets'
for f in os.listdir(assets_dir):
    if f not in keep:
        os.remove(os.path.join(assets_dir, f))
        print(f'Removed: {f}')
    else:
        print(f'Kept: {f}')
print('Done')
